plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.zapten.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.zapten.app"
        minSdk = 28
        targetSdk = 34
        versionCode = 16
        versionName = "16.0-32"

        ndk {
            // ZapTen-v16-32: the separate 32-bit build (owner) — the same app for 32-bit boxes. Only the
            // 32-bit (armeabi-v7a) copy of every native lib (libVLC + libmpv), so the APK holds one ABI,
            // as the 64-bit build does. The 64-bit build (arm64-v8a) is the separate ZapTen-v16.
            abiFilters.add("armeabi-v7a")
        }
    }

    signingConfigs {
        create("shared") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "openstream"
            keyPassword = "android"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("shared")
        }
        release {
            // Obfuscation is ready but OFF: the app currently ships as a debug build, and the
            // proguard-rules.pro keep rules are in place so this can be flipped to true safely
            // once we move to release builds, without breaking Compose / libVLC / JSON parsing.
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("shared")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true   // exposes BuildConfig.VERSION_NAME for the in-app version label
    }

    // libVLC and libmpv each bundle their own copy of the C++ runtime (libc++_shared.so). When two
    // native libraries ship the same .so, the merge step can't choose, so tell it to keep the first
    // — they're ABI-compatible, so either works. Without this the build fails at mergeDebugNativeLibs.
    packaging {
        jniLibs {
            pickFirsts += "**/libc++_shared.so"
        }
    }

    // Name the built APK after the version (e.g. StreamLine-v236.apk) instead of app-debug.apk, so
    // each artifact self-identifies. versionCode is the running build number and bumps every build.
    val builtVersionCode = defaultConfig.versionCode
    applicationVariants.all {
        outputs.all {
            (this as com.android.build.gradle.internal.api.BaseVariantOutputImpl).outputFileName =
                "ZapTen-v${builtVersionCode}-32.apk"
        }
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.03"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.media3:media3-exoplayer:1.8.0")
    implementation("androidx.media3:media3-exoplayer-hls:1.8.0")
    implementation("androidx.media3:media3-datasource:1.8.0")
    implementation("androidx.media3:media3-ui:1.8.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("org.videolan.android:libvlc-all:3.7.0")
    implementation("dev.jdtech.mpv:libmpv:0.5.1")          // mpv engine: HW decode + libass subtitles. Upgraded from the old 0.4.1 pin (compileSdk-36 unlock). 0.5.1 is the newest release keeping the classic static MPVLib API — 1.0.0 renamed the API surface (verified by CI: every getPropertyString/setOptionString/command unresolved) and would need a full call-site migration.
    implementation("androidx.work:work-runtime-ktx:2.9.1")   // nightly background EPG refresh
    implementation("androidx.webkit:webkit:1.11.0")           // ZapTen portal mode: WebViewCompat.addDocumentStartJavaScript
}
