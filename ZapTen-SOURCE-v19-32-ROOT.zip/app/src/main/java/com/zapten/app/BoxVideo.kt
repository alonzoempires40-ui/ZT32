package com.zapten.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.VideoSize
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import dev.jdtech.mpv.MPVLib
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import org.videolan.libvlc.MediaPlayer

/**
 * ZapTen portal mode — the BOX PLAYER. The portal's own interface (c/) calls the set-top-box player
 * API (gSTB.Play / Stop / Pause / Continue / SetPosTime / GetPosTime / GetMediaLen / SetViewport …)
 * through StbBridge; this is what sits underneath and actually plays, using StreamLine's three
 * engines UNCHANGED: ExoPlayer for HLS, mpv for transport streams (hardware decode + embedded
 * subtitles), libVLC as the fallback (FFmpeg decoders, legacy Greek subtitles). The routing and the
 * error fallback (Exo → VLC → mpv) are StreamLine's (Player.kt pickEngine). Build 10: the title check
 * too (the shim passes the portal's name for the item), the forced engine from StreamLine's Settings,
 * the Exo watchdog, the subtitle auto-on polls and Exo's subtitle look — the players as in StreamLine.
 *
 * The video is drawn BEHIND the (transparent) portal page, exactly like a MAG's video plane: full
 * screen normally, or in the small preview window the interface asks for with SetViewport/SetPIG.
 *
 * Box events the interface waits for (player.js event_callback): 4 = playback started,
 * 1 = end of stream, 5 = not found / cannot play. Sent with stbEvent.onEvent(code).
 */

/** What the bridge needs from the player. Calls may come from the WebView's JS thread. */
interface BoxPlayerHost {
    /** build 10: title = the portal's name for what it plays (StreamLine's "Gr Subs" → VLC rule) */
    fun play(url: String, title: String)
    fun stop()
    fun pause()
    fun resume()
    fun seekSec(sec: Long)
    fun setVolume(pct: Int)
    /** Page coordinates (1280×720 space). w <= 0 → full screen. */
    fun setViewport(x: Int, y: Int, w: Int, h: Int)
    fun posSec(): Long
    fun lenSec(): Long
    fun isPlaying(): Boolean
    // build 10: the rest of the box player API the portal uses (FF/REW, the APP menu, ASPECT)
    /** stbPlayerManager.list[0].state: 0 idle, 1 opening, 2 playing, 3 paused */
    fun playerState(): Int
    fun audioPidsJson(): String
    fun audioPid(): Int
    fun setAudioPid(pid: Int)
    fun subtitlePidsJson(): String
    fun subtitlePid(): Int
    fun setSubtitlePid(pid: Int)
    fun setSubtitles(on: Boolean)
    /** SetAspect(mode): 0x10 fit, 0x40 big, 0x50 optimal, 0x00 expand, 0x30 combined */
    fun setAspect(mode: Int)
}

/** Playback state shared between the bridge (JS thread), the video layer (compose) and the page. */
class BoxPlayerState(private val appCtx: Context? = null) : BoxPlayerHost {
    private val main = Handler(Looper.getMainLooper())

    // compose-observed
    var url by mutableStateOf<String?>(null)
    var engine by mutableStateOf("exo")
    var gen by mutableStateOf(0)                       // bumps to force a fresh player
    var rect by mutableStateOf<IntArray?>(null)        // page px [x,y,w,h]; null = full screen
    var volumePct by mutableStateOf(100)
    var aspectMode by mutableStateOf(0x10)             // build 10: the portal's SetAspect (fit)
    var videoAspect by mutableStateOf(0f)              // build 10: the picture's shape (w/h), 0 = not known yet

    // live controller + snapshot for the bridge thread
    @Volatile var controller: PlaybackController? = null
    @Volatile private var snapPos = 0L
    @Volatile private var snapLen = 0L
    @Volatile private var snapPlaying = false
    @Volatile var started = false
    private var triedVlc = false
    private var triedMpv = false
    // build 10
    @Volatile private var active = false
    @Volatile private var snapAudio: List<TrackOption> = emptyList()
    @Volatile private var snapSubs: List<TrackOption> = emptyList()
    @Volatile private var snapAid = -1
    @Volatile private var snapSid = -1
    private var trackSig: String? = null
    private var sent7 = false
    /** The portal (or the viewer, from the APP menu) chose the subtitles: StreamLine's auto-on stops. */
    @Volatile var subsChosen = false
    /** ExoPlayer decoded a picture (StreamLine's watchdog: none in 6 s → VLC). */
    @Volatile var exoVideo = false
    private var exoWatchdogDone = false

    /** Set by the portal screen: sends stbEvent.onEvent(code) into the page. */
    var sendEvent: (Int) -> Unit = {}

    /** StreamLine's Settings → Playback engine (auto / exo / vlc / mpv). */
    private fun forced(): String = appCtx?.let { runCatching { Prefs.engine(it) }.getOrNull() } ?: "auto"

    // ---- StreamLine's engine choice (Player.kt pickEngine): forced engine, the title rule, the URL ----
    private fun pickEngine(u: String, title: String): String {
        val f = forced()
        if (f == "vlc") return "vlc"
        if (f == "exo") return "exo"
        if (f == "mpv") return "mpv"
        val t = title.lowercase()
        if (Regex("gr(eek)?[\\s._-]*subs?").containsMatchIn(t) || t.contains("greek")) return "vlc"
        val low = u.lowercase()
        val looksHls = low.contains(".m3u8")
        val looksTs = low.contains("mpegts") || low.contains(".ts") || low.contains("/ts") ||
            low.startsWith("rtp") || low.startsWith("udp") || low.startsWith("rtsp")
        return when {
            looksTs -> "mpv"
            looksHls -> "exo"
            else -> "exo"
        }
    }

    /** "ffmpeg http://…", "auto http://…", "ffrt …" → the URL itself (the box solution word is dropped). */
    private fun stripSolution(uri: String): String {
        val s = uri.trim()
        val sp = s.indexOf(' ')
        return if (sp > 0 && !s.substring(0, sp).contains("://")) s.substring(sp + 1).trim() else s
    }

    override fun play(url: String, title: String) = main.post {
        val u = stripSolution(url)
        DebugLog.add("player: Play " + u.take(120) + (if (title.isNotBlank()) "  (" + title.take(60) + ")" else ""))
        started = false; triedVlc = false; triedMpv = false
        snapPos = 0; snapLen = 0; snapPlaying = false
        active = true; snapAudio = emptyList(); snapSubs = emptyList(); snapAid = -1; snapSid = -1
        trackSig = null; sent7 = false; subsChosen = false; exoVideo = false; exoWatchdogDone = false
        videoAspect = 0f
        engine = pickEngine(u, title)
        this.url = u
        gen++
        DebugLog.add("player: engine " + engine)
    }.let { }

    override fun stop() = main.post {
        if (url != null) DebugLog.add("player: Stop")
        url = null; controller = null; started = false
        snapPos = 0; snapLen = 0; snapPlaying = false
        active = false; snapAudio = emptyList(); snapSubs = emptyList(); snapAid = -1; snapSid = -1
    }.let { }

    override fun pause() = main.post { controller?.let { if (it.isPlaying()) it.playPause() } }.let { }
    override fun resume() = main.post { controller?.let { if (!it.isPlaying()) it.playPause() } }.let { }
    override fun seekSec(sec: Long) = main.post { controller?.seekTo(sec * 1000) }.let { }
    override fun setVolume(pct: Int) = main.post { volumePct = pct.coerceIn(0, 100); applyVolume() }.let { }
    override fun setViewport(x: Int, y: Int, w: Int, h: Int) = main.post {
        rect = if (w <= 0 || h <= 0) null else intArrayOf(x, y, w, h)
        DebugLog.add("player: viewport " + (rect?.joinToString(",") ?: "full screen"))
    }.let { }

    override fun posSec(): Long = snapPos / 1000
    override fun lenSec(): Long = snapLen / 1000
    override fun isPlaying(): Boolean = snapPlaying

    // ---- build 10: the box API behind FF/REW, the APP menu and ASPECT ----
    override fun playerState(): Int = when { !active -> 0; snapPlaying -> 2; started -> 3; else -> 1 }

    /** The portal's track list format: [{"pid":…, "lang":["…",""]}] (+ "selected" for the subtitle shown). */
    private fun tracksJson(list: List<TrackOption>, shownId: Int): String {
        val arr = JSONArray()
        for (t in list) {
            val o = JSONObject()
            o.put("pid", t.id)
            o.put("lang", JSONArray().put(t.label).put(""))
            if (shownId >= 0 && t.id == shownId) o.put("selected", true)
            arr.put(o)
        }
        return arr.toString()
    }
    override fun audioPidsJson(): String = tracksJson(snapAudio, -1)
    /** Always a pid from the list (the portal's audio menu breaks on an unknown one). */
    override fun audioPid(): Int {
        val l = snapAudio
        val cur = snapAid
        return if (l.any { it.id == cur }) cur else l.firstOrNull()?.id ?: 0
    }
    override fun setAudioPid(pid: Int) = main.post {
        DebugLog.add("player: audio track " + pid)
        controller?.selectAudio(pid)
    }.let { }
    override fun subtitlePidsJson(): String = tracksJson(snapSubs, snapSid)
    override fun subtitlePid(): Int = snapSid
    override fun setSubtitlePid(pid: Int) = main.post {
        if (url == null) return@post
        DebugLog.add("player: subtitle track " + pid)
        subsChosen = true
        controller?.selectSpu(pid)
    }.let { }
    override fun setSubtitles(on: Boolean) = main.post {
        if (url == null || !started) return@post
        DebugLog.add("player: subtitles " + (if (on) "on" else "off"))
        subsChosen = true
        val c = controller ?: return@post
        if (!on) { c.selectSpu(-1); return@post }
        if (c.currentSpu() < 0) c.enableFirstSubtitle()
    }.let { }
    override fun setAspect(mode: Int) = main.post {
        aspectMode = mode and 0xF0
        DebugLog.add("player: aspect 0x" + Integer.toHexString(aspectMode))
    }.let { }

    /** StreamLine's watchdog (Player.kt): Exo on Auto shows no picture within 6 s → VLC, once per stream. */
    fun exoWatchdog() {
        if (url == null || engine != "exo" || exoVideo || exoWatchdogDone || forced() == "exo") return
        exoWatchdogDone = true; triedVlc = true
        DebugLog.add("player: Exo shows no picture after 6 s → VLC")
        engine = "vlc"; gen++
    }

    private fun aspectOf(c: PlaybackController): Float = runCatching {
        when (c) {
            is ExoController -> c.exo?.videoSize?.let { v -> if (v.width > 0 && v.height > 0) v.width * v.pixelWidthHeightRatio / v.height else 0f } ?: 0f
            is VlcController -> c.player?.currentVideoTrack?.let { v ->
                if (v.width > 0 && v.height > 0) {
                    val sar = if (v.sarNum > 0 && v.sarDen > 0) v.sarNum.toFloat() / v.sarDen else 1f
                    v.width * sar / v.height
                } else 0f
            } ?: 0f
            is MpvController -> if (c.ready) MPVLib.getPropertyString("video-params/aspect")?.toFloatOrNull() ?: 0f else 0f
            else -> 0f
        }
    }.getOrDefault(0f)

    /** Called by the engine composables (main thread). */
    fun attach(c: PlaybackController) { controller = c; applyVolume() }

    fun applyVolume() {
        val v = volumePct
        when (val c = controller) {
            is ExoController -> c.exo?.volume = v / 100f
            is VlcController -> runCatching { c.player?.volume = v }
            is MpvController -> if (c.ready) runCatching { MPVLib.setPropertyString("volume", v.toString()) }
            else -> {}
        }
    }

    /** Polled from the video layer (main thread): updates the snapshot, raises started / ended. */
    fun poll() {
        val c = controller ?: return
        val playing = c.isPlaying(); val pos = c.positionMs(); val len = c.durationMs()
        snapPlaying = playing; snapPos = pos; snapLen = len
        if (!started && (playing || pos > 0)) { started = true; DebugLog.add("player: started → event 4"); sendEvent(4) }
        // build 10: the tracks for the portal's APP menu (Audio / Subtitles) and the picture's shape
        val au = runCatching { c.audioTracks().filter { it.id >= 0 } }.getOrDefault(emptyList())
        val su = runCatching { c.subtitleTracks().filter { it.id >= 0 } }.getOrDefault(emptyList())
        snapAudio = au; snapSubs = su
        snapAid = runCatching { c.currentAudio() }.getOrDefault(-1)
        snapSid = runCatching { c.currentSpu() }.getOrDefault(-1)
        val a = aspectOf(c)
        if (a > 0f && kotlin.math.abs(a - videoAspect) > 0.01f) videoAspect = a
        if (started) {
            // like a box: 7 = "video content info" (the portal reads the tracks and builds the menu),
            // then 9 whenever the stream's tracks change (the portal reads them again)
            val sig = au.joinToString(",") { it.id.toString() + ":" + it.label } + "|" + su.joinToString(",") { it.id.toString() + ":" + it.label }
            if (sig != trackSig) {
                trackSig = sig
                if (!sent7) { sent7 = true; DebugLog.add("player: video info → event 7"); sendEvent(7) }
                DebugLog.add("player: tracks " + au.size + " audio, " + su.size + " subtitles → event 9")
                sendEvent(9)
            }
        }
        // VOD end for the polled engines (VLC / mpv): past the end and no longer playing
        if (started && len > 0 && !playing && pos >= len - 1500 && engine != "exo") onEnded()
    }

    fun onStarted() { if (!started) { started = true; DebugLog.add("player: started → event 4"); sendEvent(4) } }
    fun onEnded() {
        if (url == null) return
        DebugLog.add("player: end of stream → event 1")
        url = null; controller = null; started = false; snapPlaying = false; active = false
        sendEvent(1)
    }

    /** StreamLine's fallback chain: Exo → VLC → mpv → give up (box event 5). An engine forced in
     *  StreamLine's Settings does not fall back (as in StreamLine). */
    fun onError(which: String, why: String) {
        DebugLog.add("player: " + which + " error: " + why)
        if (url == null) return
        val f = forced()
        when {
            which == "exo" && f != "exo" && !triedVlc -> { triedVlc = true; engine = "vlc"; gen++; DebugLog.add("player: falling back to VLC") }
            which == "vlc" && f != "vlc" && !triedMpv -> { triedMpv = true; engine = "mpv"; gen++; DebugLog.add("player: falling back to mpv") }
            which == "mpv" && f != "mpv" && !triedVlc -> { triedVlc = true; engine = "vlc"; gen++; DebugLog.add("player: falling back to VLC") }
            else -> { DebugLog.add("player: cannot play → event 5"); url = null; controller = null; started = false; active = false; sendEvent(5) }
        }
    }
}

/** ExoPlayer behind StreamLine's engine-agnostic controller surface (the Exo path of Player.kt). */
class ExoController : PlaybackController {
    var exo: ExoPlayer? = null
    override fun playPause() { exo?.let { if (it.isPlaying) it.pause() else it.play() } }
    override fun isPlaying(): Boolean = exo?.isPlaying ?: false
    override fun positionMs(): Long = exo?.currentPosition ?: 0
    override fun durationMs(): Long = exo?.duration?.takeIf { it > 0 } ?: 0
    override fun seekTo(ms: Long) { exo?.seekTo(ms) }
    override fun seekBy(deltaMs: Long) = seekTo((positionMs() + deltaMs).coerceAtLeast(0))
    override fun setRate(rate: Float) { exo?.setPlaybackSpeed(rate) }
    // build 10: StreamLine's Exo track helpers (Player.kt exoTrackList / exoSelectTrack / exoDisableType)
    private fun tracks(type: Int): List<TrackOption> {
        val out = mutableListOf<TrackOption>()
        val groups = exo?.currentTracks?.groups ?: return out
        groups.forEachIndexed { gi, g ->
            if (g.type != type) return@forEachIndexed
            for (ti in 0 until g.length) {
                val f = g.getTrackFormat(ti)
                val lbl = f.label ?: f.language ?: "Track ${gi + 1}.${ti + 1}"
                out.add(TrackOption(gi * 1000 + ti, lbl, g.isTrackSelected(ti)))
            }
        }
        return out
    }
    private fun select(encodedId: Int) {
        val p = exo ?: return
        val g = p.currentTracks.groups.getOrNull(encodedId / 1000) ?: return
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(g.type, false)
            .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, listOf(encodedId % 1000)))
            .build()
    }
    override fun audioTracks(): List<TrackOption> = tracks(C.TRACK_TYPE_AUDIO)
    override fun subtitleTracks(): List<TrackOption> = tracks(C.TRACK_TYPE_TEXT)
    override fun currentAudio(): Int = tracks(C.TRACK_TYPE_AUDIO).firstOrNull { it.selected }?.id ?: -1
    override fun currentSpu(): Int = tracks(C.TRACK_TYPE_TEXT).firstOrNull { it.selected }?.id ?: -1
    override fun selectAudio(id: Int) { if (id >= 0) select(id) }
    override fun selectSpu(id: Int) {
        val p = exo ?: return
        if (id < 0) p.trackSelectionParameters = p.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build()
        else select(id)
    }
    override fun enableFirstSubtitle(): Int {
        val first = subtitleTracks().firstOrNull() ?: return -1
        select(first.id)
        return first.id
    }
}

/** build 10: the picture's size on the screen for the portal's aspect modes. null = the whole
 *  picture fitted to the screen (fit); else [width, height, stretch-to] in dp, centred, cropped by the
 *  screen edges; stretch-to > 0 = the engine stretches the picture to that shape (w/h). */
private fun ztAspectBox(mode: Int, a: Float, w: Float, h: Float): FloatArray? {
    if (w <= 0f || h <= 0f) return null
    val s = w / h
    if (mode == 0x00) return floatArrayOf(w, h, s)                                   // expand: stretched to the screen
    if (a <= 0f) return null
    fun cover(r: Float) = if (r > s) floatArrayOf(h * r, h) else floatArrayOf(w, w / r)
    return when (mode) {
        0x40 -> cover(a).let { floatArrayOf(it[0], it[1], 0f) }                       // big: fills, sides/top cut
        0x50 -> {                                                                     // optimal: half way to big
            val fit = if (a > s) floatArrayOf(w, w / a) else floatArrayOf(h * a, h)
            val big = cover(a)
            floatArrayOf((fit[0] + big[0]) / 2f, (fit[1] + big[1]) / 2f, 0f)
        }
        0x30 -> {                                                                     // combined: half stretched, half cut
            val t = (a + s) / 2f
            cover(t).let { floatArrayOf(it[0], it[1], t) }
        }
        else -> null
    }
}

/** The video layer: full screen or the interface's preview window, one of the three engines. */
@Composable
fun BoxVideo(state: BoxPlayerState, referer: String, viewWidthPx: Int) {
    val url = state.url
    val density = LocalDensity.current.density
    // page (1280-wide) → view pixels
    val k = if (viewWidthPx > 0) viewWidthPx / 1280f else 1f
    val r = state.rect

    BoxWithConstraints(Modifier.fillMaxSize().background(Color.Black)) {
        // build 10: the portal's ASPECT, on the full-screen picture
        val box = if (r == null) ztAspectBox(state.aspectMode, state.videoAspect, maxWidth.value, maxHeight.value) else null
        val stretch = box?.get(2) ?: 0f
        val mod = when {
            r != null -> Modifier.offset { IntOffset((r[0] * k).toInt(), (r[1] * k).toInt()) }
                .size(((r[2] * k) / density).dp, ((r[3] * k) / density).dp)
            box != null -> Modifier.align(Alignment.Center).requiredSize(box[0].dp, box[1].dp)
            else -> Modifier.fillMaxSize()
        }
        if (url != null) {
            key(state.gen, url, state.engine) {
                when (state.engine) {
                    "vlc" -> {
                        val c = remember { VlcController() }
                        LaunchedEffect(Unit) { state.attach(c) }
                        VlcPlayer(url, c, mod, userAgent = BoxCrypto.USER_AGENT, referer = referer,
                            onError = { state.onError("vlc", "EncounteredError") })
                        // StreamLine (Player.kt): subtitle tracks are known only after the stream starts —
                        // poll ~20 s and switch the first one on (unless the portal / the viewer chose)
                        LaunchedEffect(Unit) {
                            var on = false
                            repeat(40) { delay(500); if (!on && !state.subsChosen && c.enableFirstSubtitle() >= 0) on = true }
                        }
                        // build 10: ASPECT — expand / combined stretch the picture, the rest keep its shape
                        LaunchedEffect(stretch > 0f) {
                            repeat(50) { if (c.player == null) delay(100) }
                            runCatching { c.player?.setVideoScale(if (stretch > 0f) MediaPlayer.ScaleType.SURFACE_FILL else MediaPlayer.ScaleType.SURFACE_BEST_FIT) }
                        }
                    }
                    "mpv" -> {
                        val c = remember { MpvController() }
                        LaunchedEffect(Unit) { state.attach(c) }
                        MpvPlayer(url, c, mod, userAgent = BoxCrypto.USER_AGENT, referer = referer,
                            onError = { state.onError("mpv", "init failed") })
                        // StreamLine (Player.kt): the same for mpv, polled up to ~5 min (TS streams can
                        // announce the subtitle track only when its first lines arrive)
                        LaunchedEffect(Unit) {
                            var on = false
                            repeat(600) { delay(500); if (!on && !state.subsChosen && c.enableFirstSubtitle() >= 0) on = true }
                        }
                        // build 10: ASPECT — stretch = mpv shows the picture with the box's shape
                        val lastStretch = remember { floatArrayOf(0f) }
                        LaunchedEffect(stretch) {
                            if (stretch == lastStretch[0]) return@LaunchedEffect
                            repeat(100) { if (!c.ready) delay(200) }
                            if (c.ready) runCatching {
                                MPVLib.setPropertyString("video-aspect-override", if (stretch > 0f) stretch.toString() else "-1")
                                lastStretch[0] = stretch
                            }
                        }
                    }
                    else -> ExoBox(url, state, referer, mod, fill = stretch > 0f)
                }
                // the snapshot the bridge reads, and started/ended for the polled engines
                LaunchedEffect(Unit) { while (true) { state.poll(); delay(400) } }
            }
        }
    }
}

@Composable
private fun ExoBox(url: String, state: BoxPlayerState, referer: String, modifier: Modifier, fill: Boolean = false) {
    val ctx = LocalContext.current
    val c = remember { ExoController() }
    val exo = remember(url) {
        // StreamLine's Exo setup: the box User-Agent (+ Referer) the streamers gate on.
        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent(BoxCrypto.USER_AGENT)
            .setAllowCrossProtocolRedirects(true)
            .setKeepPostFor302Redirects(true)
            .setDefaultRequestProperties(mapOf("Referer" to referer))
        ExoPlayer.Builder(ctx).setMediaSourceFactory(DefaultMediaSourceFactory(httpFactory)).build().apply {
            trackSelectionParameters = trackSelectionParameters.buildUpon().setSelectUndeterminedTextLanguage(true).build()
            addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    if (playbackState == Player.STATE_READY) state.onStarted()
                    if (playbackState == Player.STATE_ENDED) state.onEnded()
                }
                override fun onPlayerError(error: PlaybackException) { state.onError("exo", error.errorCodeName) }
                override fun onVideoSizeChanged(videoSize: VideoSize) { if (videoSize.width > 0) state.exoVideo = true }
            })
            setMediaItem(MediaItem.fromUri(url)); prepare(); playWhenReady = true
        }
    }
    c.exo = exo
    LaunchedEffect(exo) { state.attach(c) }
    // build 10: StreamLine's watchdog — no picture after 6 s on Auto → VLC
    LaunchedEffect(exo) { delay(6000); state.exoWatchdog() }
    AndroidView(
        factory = { cx -> PlayerView(cx).apply {
            useController = false; player = exo; setBackgroundColor(android.graphics.Color.BLACK)
            // build 10: StreamLine's subtitle look (Player.kt): white outlined text, no box, its size slider
            subtitleView?.apply {
                setApplyEmbeddedStyles(false)
                setStyle(
                    androidx.media3.ui.CaptionStyleCompat(
                        android.graphics.Color.WHITE,
                        android.graphics.Color.TRANSPARENT,
                        android.graphics.Color.TRANSPARENT,
                        androidx.media3.ui.CaptionStyleCompat.EDGE_TYPE_OUTLINE,
                        android.graphics.Color.BLACK,
                        null
                    )
                )
                setFractionalTextSize(0.0533f * Prefs.subScaleFor(ctx, "exo") / 100f)
            }
        } },
        update = {
            it.player = exo
            it.resizeMode = if (fill) AspectRatioFrameLayout.RESIZE_MODE_FILL else AspectRatioFrameLayout.RESIZE_MODE_FIT
        },
        modifier = modifier
    )
    DisposableEffect(exo) { onDispose { c.exo = null; runCatching { exo.release() } } }
}
