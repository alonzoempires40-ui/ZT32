package com.zapten.app

import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.mutableStateListOf

/**
 * A simple in-memory log the on-screen debug panel shows. Lines come from the WebView callbacks
 * (page load, HTTP and SSL errors, console messages) and from the injected JS (via StbBridge.log),
 * so the black-screen case still shows what the portal actually returned. Nothing is sent anywhere;
 * it lives only in memory for this run.
 */
object DebugLog {
    private const val MAX = 400
    private val main = Handler(Looper.getMainLooper())
    val lines = mutableStateListOf<String>()

    fun add(line: String) {
        val t = java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.US).format(java.util.Date())
        val entry = "$t  $line"
        main.post {
            lines.add(entry)
            while (lines.size > MAX) lines.removeAt(0)
        }
    }

    fun clear() { main.post { lines.clear() } }

    /** The whole log as one string (for the Copy button). */
    fun dump(): String = lines.joinToString("\n")
}
