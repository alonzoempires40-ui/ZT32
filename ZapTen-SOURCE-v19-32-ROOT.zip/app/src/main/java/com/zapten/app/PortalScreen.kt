package com.zapten.app

import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.net.http.SslError
import android.os.SystemClock
import android.view.KeyEvent
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.CookieManager
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.foundation.Canvas
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

/*
 * ZapTen portal mode (build 6) — the provider's own MAG interface (stalker_portal/c/) in a WebView
 * with the set-top-box API (StbBridge) underneath, StreamLine's three video engines behind it
 * (BoxVideo), an on-screen remote for touch screens, and the log. Added on top of StreamLine 40
 * unchanged; StreamLine's own screens stay reachable from the setup screen.
 */

/** Setup: portal address(es) and this box's MAC to give the provider. */
@Composable
fun ZtSetupScreen(onOpen: () -> Unit, onStreamLine: () -> Unit) {
    val ctx = LocalContext.current
    var active by remember { mutableStateOf(BoxPrefs.activePortal(ctx)) }
    var url1 by remember { mutableStateOf(BoxPrefs.url(ctx, 1)) }
    var url2 by remember { mutableStateOf(BoxPrefs.url(ctx, 2)) }
    val mac = remember(active) { BoxPrefs.mac(ctx, active) }

    Column(Modifier.fillMaxSize().background(Ink).verticalScroll(rememberScrollState()).padding(28.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Zap", color = TextCol, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
            Text("Ten", color = Amber, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
        }
        Spacer(Modifier.height(4.dp))
        Text("Opens your provider's own portal, like a set-top box.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(20.dp))

        Text("PORTAL", color = Amber, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ZtChip("Portal 1", active == 1) { active = 1; BoxPrefs.saveActivePortal(ctx, 1) }
            ZtChip("Portal 2", active == 2) { active = 2; BoxPrefs.saveActivePortal(ctx, 2) }
        }
        Spacer(Modifier.height(20.dp))

        ZtField("Portal $active address", if (active == 1) url1 else url2, placeholder = "subdomain.domain.com") { v ->
            if (active == 1) url1 = v else url2 = v
        }
        Spacer(Modifier.height(16.dp))

        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(16.dp)) {
            Text("THIS BOX'S MAC — give it to your provider", color = Amber, fontSize = 10.sp,
                fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Spacer(Modifier.height(6.dp))
            Text(mac, color = TextCol, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text("Portal $active uses this MAC. Portal 1 and Portal 2 each have their own.", color = Muted, fontSize = 12.sp)
        }
        Spacer(Modifier.height(24.dp))

        Button(
            onClick = {
                BoxPrefs.saveUrl(ctx, 1, url1); BoxPrefs.saveUrl(ctx, 2, url2); BoxPrefs.saveActivePortal(ctx, active)
                if (BoxPrefs.url(ctx, active).isNotBlank()) { BoxPrefs.markSetupDone(ctx); onOpen() }
            },
            colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color(0xFF1A1304)),
            modifier = Modifier.fillMaxWidth().height(50.dp)
        ) { Text("Open portal $active", fontWeight = FontWeight.Bold, fontSize = 16.sp) }

        Spacer(Modifier.height(12.dp))
        Button(
            onClick = onStreamLine,
            colors = ButtonDefaults.buttonColors(containerColor = Panel, contentColor = TextCol),
            modifier = Modifier.fillMaxWidth().height(44.dp)
        ) { Text("StreamLine screens (the app's own interface)", fontWeight = FontWeight.SemiBold, fontSize = 13.sp) }
        Spacer(Modifier.height(8.dp))
        Text("The StreamLine screens use their own MAC (shown on their welcome screen), separate from the one above.",
            color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun ZtChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(label, color = if (selected) Color(0xFF1A1304) else TextCol, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.background(if (selected) Amber else Panel, RoundedCornerShape(10.dp)).clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 9.dp))
}

@Composable
private fun ZtField(label: String, value: String, placeholder: String, onChange: (String) -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Text(label, color = Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(
            value = value, onValueChange = onChange, singleLine = true,
            placeholder = { Text(placeholder, color = Muted, fontSize = 13.sp) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Amber, unfocusedBorderColor = Line,
                focusedTextColor = TextCol, unfocusedTextColor = TextCol, cursorColor = Amber),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

/** Only the domain is needed: no scheme → https://, no path → /stalker_portal, then /c/. */
fun ztPortalPageUrl(input: String): String {
    var s = input.trim()
    if (s.isEmpty()) return ""
    if (!s.startsWith("http://") && !s.startsWith("https://")) s = "https://$s"
    s = s.trimEnd('/')
    s = s.removeSuffix("/c").trimEnd('/')
    val path = s.substringAfter("://").substringAfter('/', "")
    if (path.isEmpty()) s = "$s/stalker_portal"
    return "$s/c/"
}

/** The portal page over the box player, plus the controls. */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun ZtPortalScreen(onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val portal = remember { BoxPrefs.activePortal(ctx) }
    val pageUrl = remember { ztPortalPageUrl(BoxPrefs.url(ctx, portal)) }
    val player = remember { BoxPlayerState(ctx.applicationContext) }
    var webRef by remember { mutableStateOf<WebView?>(null) }
    var lastBack by remember { mutableStateOf(0L) }
    var showLog by remember { mutableStateOf(false) }
    val hasTouch = remember { ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN) }
    var showRemote by remember { mutableStateOf(true) }        // build 19: also on a TV, as on the tablet (owner)
    val viewWidthPx = remember { ctx.resources.displayMetrics.widthPixels }
    // build 8
    var portalReady by remember { mutableStateOf(false) }       // the portal's menu / start screen is up
    var loadPct by remember { mutableStateOf(0) }               // the portal's own loading bar
    var loadGen by remember { mutableStateOf(0) }               // bumps on every page start
    var loadTimedOut by remember { mutableStateOf(false) }      // after 15 s the portal shows anyway (its own messages)
    var windowUrl by remember { mutableStateOf<String?>(null) } // the box's second window (the portal's Settings page)
    var winRef by remember { mutableStateOf<WebView?>(null) }
    var ctlShown by remember { mutableStateOf(false) }          // StreamLine-style controls on the full-screen picture
    var ctlTouch by remember { mutableStateOf(0L) }
    var ctlTitle by remember { mutableStateOf("") }
    var ctlLive by remember { mutableStateOf(false) }
    var remoteTouch by remember { mutableStateOf(0L) }
    var mouseUsed by remember { mutableStateOf(false) }      // build 18: a mouse has been used here
    // build 19: a pointer for any remote (hold OK 1 s), to press the on-screen remote's buttons from a TV remote
    var ptrOn by remember { mutableStateOf(false) }
    var ptrX by remember { mutableStateOf(-1f) }
    var ptrY by remember { mutableStateOf(-1f) }
    var ptrFx by remember { mutableStateOf(0L) }
    val okHold = remember { LongArray(1) }      // 1 = this OK press switched the pointer
    var remoteAwake by remember { mutableStateOf(true) }
    // build 10: the film controls' position / length / playing, and "the portal's own position bar is up"
    var ctlPos by remember { mutableStateOf(0L) }
    var ctlLen by remember { mutableStateOf(0L) }
    var ctlPlaying by remember { mutableStateOf(false) }
    var seekHoldUntil by remember { mutableStateOf(0L) }

    // A remote key for the portal page (its keydown observer): code + Shift/Alt, like a MAG remote.
    // Build 8: sent as a REAL key press (a box's browser gets real keys), so pages that use the
    // browser's own focus (the Settings window) react too; it goes to the Settings window while that
    // is open, else to the portal page. A code with no Android key keeps the build-7 way.
    // Build 10: the PORTAL page gets the key as the page event a MAG's browser makes (key code +
    // Shift/Alt) — as real Android keys Shift/Alt got lost and most of the remote did nothing there.
    // The Settings window keeps the real key presses.
    fun sendKey(code: Int, shift: Boolean = false, alt: Boolean = false) {
        if (alt && (code == 66 || code == 70)) seekHoldUntil = System.currentTimeMillis() + 4_500   // ◀◀ ▶▶: the portal's position bar
        if (winRef == null) {
            // build 13: the shim's delivery (to the focused element, keydown/keypress/keyup, digits type into
            // a text box) — the build-10 bare keydown on the body stays only as the fallback before the shim is up
            webRef?.evaluateJavascript(
                "(function(){if(window.__ztKey){__ztKey(" + code + "," + shift + "," + alt + ");return;}" +
                    "var e=new KeyboardEvent('keydown',{bubbles:true,cancelable:true,shiftKey:" + shift + ",altKey:" + alt + "});" +
                    "Object.defineProperty(e,'keyCode',{get:function(){return " + code + "}});" +
                    "Object.defineProperty(e,'which',{get:function(){return " + code + "}});" +
                    "(document.body||document).dispatchEvent(e);})();", null)
            return
        }
        val target = winRef ?: webRef ?: return
        val ak = ztAndroidKey(code)
        if (ak == null) {
            target.evaluateJavascript(
                "(function(){var e=new KeyboardEvent('keydown',{bubbles:true,shiftKey:" + shift + ",altKey:" + alt + "});" +
                    "Object.defineProperty(e,'keyCode',{get:function(){return " + code + "}});" +
                    "Object.defineProperty(e,'which',{get:function(){return " + code + "}});" +
                    "document.dispatchEvent(e);})();", null)
            return
        }
        var meta = 0
        if (shift) meta = meta or KeyEvent.META_SHIFT_ON or KeyEvent.META_SHIFT_LEFT_ON
        if (alt) meta = meta or KeyEvent.META_ALT_ON or KeyEvent.META_ALT_LEFT_ON
        if (!target.hasFocus()) target.requestFocus()
        val t = SystemClock.uptimeMillis()
        target.dispatchKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, ak, 0, meta))
        target.dispatchKeyEvent(KeyEvent(t, SystemClock.uptimeMillis(), KeyEvent.ACTION_UP, ak, 0, meta))
    }

    // The remote's Setup button: a box opens its settings; here the portal's own Settings tile runs.
    fun openPortalSettings() {
        webRef?.evaluateJavascript(
            "(function(){try{var m=(window.main_menu&&main_menu.map)||[];for(var i=0;i<m.length;i++){var it=m[i];" +
                "if(it&&it.module&&it.module.layer_name=='settings'&&typeof it.cmd=='function'){it.cmd();return 'ok';}}return 'no settings tile';}" +
                "catch(e){return 'error '+e;}})()") { r -> DebugLog.add("Setup -> " + r) }
    }

    // build 10: the remote's TV keys — on the owner's remote they work the TV: here the tablet's own
    // volume / mute (shown with Android's volume bar); TV power / TV SET / TV/AV only say so
    fun tvVolume(adjust: Int) {
        val am = ctx.getSystemService(android.content.Context.AUDIO_SERVICE) as? android.media.AudioManager ?: return
        runCatching { am.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC, adjust, android.media.AudioManager.FLAG_SHOW_UI) }
    }
    fun tvOnly(label: String) {
        android.widget.Toast.makeText(ctx, label + " — on your remote this works the TV, not the box", android.widget.Toast.LENGTH_SHORT).show()
    }
    // build 13: the box's own keyboard — a MAG shows it when OK is pressed on a text box (the PIN box);
    // the portal asks with gSTB.ShowVirtualKeyboard / HideVirtualKeyboard → Android's keyboard
    fun showKeyboard(on: Boolean) {
        val v = winRef ?: webRef ?: return
        val w = ctx.ztFindActivity()?.window ?: return
        if (on) v.requestFocus()
        runCatching {
            val c = WindowCompat.getInsetsController(w, v)
            if (on) c.show(WindowInsetsCompat.Type.ime()) else c.hide(WindowInsetsCompat.Type.ime())
        }
        // build 19: also ask Android's keyboard service directly — some TVs bring no keyboard up for a page otherwise
        if (on) runCatching {
            (ctx.getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).showSoftInput(v, 0)
        }
    }
    // build 14: gSTB.SendEventToPortal — what the Settings window saved goes to the portal page as
    // stbEvent.onPortalEvent(json), as on a MAG, so the running portal uses it at once
    fun portalEvent(json: String) {
        webRef?.evaluateJavascript("try{stbEvent.onPortalEvent(" + JSONObject.quote(json) + ")}catch(e){}", null)
    }
    // build 10: KB = the keyboard (a MAG shows its on-screen keyboard), here Android's own
    fun toggleKeyboard() {
        val v = winRef ?: webRef ?: return
        val w = ctx.ztFindActivity()?.window ?: return
        v.requestFocus()
        runCatching {
            val c = WindowCompat.getInsetsController(w, v)
            val shown = ViewCompat.getRootWindowInsets(v)?.isVisible(WindowInsetsCompat.Type.ime()) == true
            if (shown) c.hide(WindowInsetsCompat.Type.ime()) else c.show(WindowInsetsCompat.Type.ime())
        }
    }

    // gSTB.LoadURL: file:///home/web/… is the box's own start page = the portal again; a web address loads.
    fun loadUrlInBox(u: String) {
        windowUrl = null
        if (u.startsWith("file:")) { DebugLog.add("--- portal again (reload) ---"); player.stop(); webRef?.loadUrl(pageUrl) }
        else if (u.startsWith("http")) webRef?.loadUrl(u)
    }

    // TV-remote buttons the portal does not know by their Android names → the MAG key (build 8).
    // Arrows, OK and the numbers already arrive as the portal expects; volume stays Android's.
    val tvKeys = remember {
        android.view.View.OnKeyListener { _, keyCode, ev ->
            val m = ztTvRemoteKey(keyCode) ?: return@OnKeyListener false
            if (ev.action == KeyEvent.ACTION_DOWN) sendKey(m[0], m[1] == 1, m[2] == 1)
            true
        }
    }

    // build 19: the pointer — on / off, move, press (a finger tap where it is: the on-screen remote, the page, anything)
    fun pointerRoot(): android.view.View? = ctx.ztFindActivity()?.findViewById(android.R.id.content)
    fun togglePointer() {
        ptrOn = !ptrOn
        if (ptrOn) {
            val r = pointerRoot()
            if (r != null && (ptrX < 0f || ptrX >= r.width || ptrY < 0f || ptrY >= r.height)) { ptrX = r.width / 2f; ptrY = r.height / 2f }
            showRemote = true
            remoteTouch = System.currentTimeMillis()
        }
    }
    fun pointerMove(keyCode: Int, rep: Int) {
        val r = pointerRoot() ?: return
        val step = (14f + rep * 4f).coerceAtMost(72f) * ctx.resources.displayMetrics.density
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> ptrY -= step
            KeyEvent.KEYCODE_DPAD_DOWN -> ptrY += step
            KeyEvent.KEYCODE_DPAD_LEFT -> ptrX -= step
            KeyEvent.KEYCODE_DPAD_RIGHT -> ptrX += step
        }
        ptrX = ptrX.coerceIn(0f, (r.width - 1).coerceAtLeast(0).toFloat())
        ptrY = ptrY.coerceIn(0f, (r.height - 1).coerceAtLeast(0).toFloat())
        remoteTouch = System.currentTimeMillis()
    }
    fun pointerPress() {
        val r = pointerRoot() ?: return
        val t = SystemClock.uptimeMillis()
        val down = android.view.MotionEvent.obtain(t, t, android.view.MotionEvent.ACTION_DOWN, ptrX, ptrY, 0)
        val up = android.view.MotionEvent.obtain(t, t + 60, android.view.MotionEvent.ACTION_UP, ptrX, ptrY, 0)
        down.source = android.view.InputDevice.SOURCE_TOUCHSCREEN
        up.source = android.view.InputDevice.SOURCE_TOUCHSCREEN
        r.dispatchTouchEvent(down)
        r.dispatchTouchEvent(up)
        down.recycle()
        up.recycle()
        ptrFx = System.currentTimeMillis()
        remoteTouch = System.currentTimeMillis()
    }

    // build 17: a TV's / Android box's own remote goes the on-screen remote's way (sendKey), which works.
    // Given to the page as Android keys it did not: the portal blocks the browser's own handling of no key
    // but Tab, so Android's browser acted on the arrows / OK too (its own focus, scrolling, clicks — its
    // remote mode) and Android could move the focus off the page. MainActivity asks here before any view.
    // Back stays the BackHandler's; volume, Home, power and the app buttons stay Android's. Before the
    // portal is up nothing changes (ZapTen's Settings / Reload buttons).
    DisposableEffect(Unit) {
        val h: (KeyEvent) -> Boolean = h@{ ev ->
            if (!portalReady && windowUrl == null) return@h false
            // build 19: the pointer. OK: a short press = OK (a press where the pointer is, while it is on); held
            // 1 second = the pointer on / off. While it is on, the arrows move it and Back switches it off.
            val kc = ev.keyCode
            if (kc == KeyEvent.KEYCODE_DPAD_CENTER || kc == KeyEvent.KEYCODE_ENTER || kc == KeyEvent.KEYCODE_NUMPAD_ENTER ||
                kc == KeyEvent.KEYCODE_BUTTON_SELECT || kc == KeyEvent.KEYCODE_BUTTON_A) {
                if (ev.action == KeyEvent.ACTION_DOWN) {
                    if (ev.repeatCount == 0) {
                        okHold[0] = 0L
                    } else if (okHold[0] == 0L && ev.eventTime - ev.downTime >= 1000) {
                        okHold[0] = 1L
                        togglePointer()
                    }
                } else if (ev.action == KeyEvent.ACTION_UP) {
                    if (okHold[0] == 0L) {
                        if (ev.eventTime - ev.downTime >= 1000) togglePointer()
                        else if (ptrOn) pointerPress()
                        else sendKey(13)
                    }
                    okHold[0] = 0L
                }
                return@h true
            }
            if (ptrOn) {
                if (kc == KeyEvent.KEYCODE_DPAD_UP || kc == KeyEvent.KEYCODE_DPAD_DOWN || kc == KeyEvent.KEYCODE_DPAD_LEFT || kc == KeyEvent.KEYCODE_DPAD_RIGHT) {
                    if (ev.action == KeyEvent.ACTION_DOWN) pointerMove(kc, ev.repeatCount)
                    return@h true
                }
                if (kc == KeyEvent.KEYCODE_BACK) {
                    if (ev.action == KeyEvent.ACTION_UP) ptrOn = false
                    return@h true
                }
            }
            val m = ztRemoteButton(ev.keyCode) ?: return@h false
            // held arrows / page keys repeat (as on a MAG); a held OK or other button counts once
            if (ev.action == KeyEvent.ACTION_DOWN && (ev.repeatCount == 0 || m[0] in 33..40)) {
                // build 18: a remote's Settings key = the on-screen SET; Subtitles = APP while a picture plays full screen
                if (m[0] == ZT_SETUP) openPortalSettings()
                else if (ev.keyCode != KeyEvent.KEYCODE_CAPTIONS || (player.url != null && player.rect == null)) sendKey(m[0], m[1] == 1, m[2] == 1)
            }
            true
        }
        ZtRemoteKeys.handler = h
        // build 18: a mouse (USB, Bluetooth, air mouse). On a device without a touch screen the on-screen
        // remote is hidden, as before; the first time a mouse is used it comes up, with its ‹ Remote tab
        val mo: () -> Unit = {
            if (!mouseUsed) {
                mouseUsed = true
                if (!hasTouch) { showRemote = true; remoteTouch = System.currentTimeMillis() }
            }
        }
        ZtRemoteKeys.onMouse = mo
        onDispose {
            if (ZtRemoteKeys.handler === h) ZtRemoteKeys.handler = null
            if (ZtRemoteKeys.onMouse === mo) ZtRemoteKeys.onMouse = null
        }
    }

    BackHandler {
        if (showLog) { showLog = false; return@BackHandler }
        val now = System.currentTimeMillis()
        // build 8: only Back, as a MAG remote sends (build 7 sent Back + Exit together)
        if (now - lastBack < 1500) onSettings() else { lastBack = now; sendKey(8) }
    }

    // build 8: full screen — Android's status and navigation bars are hidden while the portal is open
    // (a swipe from the edge shows them for a moment); they come back when the portal screen closes.
    val act = remember { ctx.ztFindActivity() }
    DisposableEffect(act) {
        val w = act?.window
        if (w != null) runCatching {
            val c = WindowCompat.getInsetsController(w, w.decorView)
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        }
        onDispose { if (w != null) runCatching { WindowCompat.getInsetsController(w, w.decorView).show(WindowInsetsCompat.Type.systemBars()) } }
    }
    LaunchedEffect(loadGen) { loadTimedOut = false; delay(15_000); loadTimedOut = true }
    LaunchedEffect(remoteTouch) { remoteAwake = true; delay(4_000); remoteAwake = false }
    LaunchedEffect(ptrFx) { if (ptrFx != 0L) { delay(260); ptrFx = 0L } }      // build 19: the pointer's press ring
    LaunchedEffect(ctlShown, ctlTouch) { if (ctlShown) { delay(4_000); ctlShown = false } }
    // build 10: the film controls follow the picture (position, length, playing)
    LaunchedEffect(ctlShown) { while (ctlShown) { ctlPos = player.posSec(); ctlLen = player.lenSec(); ctlPlaying = player.isPlaying(); delay(500) } }
    LaunchedEffect(seekHoldUntil) { val d = seekHoldUntil - System.currentTimeMillis(); if (seekHoldUntil != 0L) { if (d > 0) delay(d); seekHoldUntil = 0L } }
    // the Settings/Reload buttons go away when the portal is up: give the TV remote's keys back to the page
    LaunchedEffect(portalReady) { if (portalReady && windowUrl == null) webRef?.requestFocus() }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        // 1. the box player, behind everything (full screen or the interface's preview window)
        BoxVideo(player, referer = pageUrl, viewWidthPx = viewWidthPx)

        // 2. the portal page, transparent, scaled so its 1280-wide layout fills the screen width
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { c ->
                CookieManager.getInstance().setAcceptCookie(true)
                DebugLog.add("open portal " + portal + ": " + pageUrl)
                DebugLog.add("MAC " + BoxPrefs.mac(ctx, portal) + "  serial " + BoxPrefs.serial(ctx, portal))
                WebView(c).apply {
                    layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                    setBackgroundColor(android.graphics.Color.TRANSPARENT)   // the video shows through
                    isVerticalScrollBarEnabled = false; isHorizontalScrollBarEnabled = false
                    overScrollMode = android.view.View.OVER_SCROLL_NEVER
                    isFocusable = true; isFocusableInTouchMode = true
                    CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                    with(settings) {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        databaseEnabled = true
                        mediaPlaybackRequiresUserGesture = false
                        userAgentString = StbBridge.userAgent()
                        // build 12: text at the theme's own size, like a MAG (Android's font-size setting
                        // made it ~1.3× bigger and broke the TV layout); the rest of the tablet keeps it
                        textZoom = 100
                        @Suppress("DEPRECATION")
                        mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                        // Full screen: the page lays out 1280 wide (screen.height is reported as 720 by the
                        // shim); the initial scale maps those 1280 CSS px onto the real screen width.
                        useWideViewPort = true
                        loadWithOverviewMode = false
                        setSupportZoom(false); builtInZoomControls = false; displayZoomControls = false
                        setSupportMultipleWindows(false)
                    }
                    val scale = (viewWidthPx / 1280f * 100f).toInt().coerceAtLeast(1)
                    setInitialScale(scale)
                    DebugLog.add("page scale " + scale + "% (screen " + viewWidthPx + " px wide → 1280 px layout)")

                    val web = this
                    player.sendEvent = { code -> web.post { web.evaluateJavascript("try{stbEvent.onEvent(" + code + ")}catch(e){}", null) } }
                    val rebootTimes = java.util.ArrayDeque<Long>()
                    addJavascriptInterface(StbBridge(c.applicationContext, portal, onReboot = {
                        web.post {
                            val now = System.currentTimeMillis()
                            while (rebootTimes.isNotEmpty() && now - rebootTimes.peekFirst()!! > 60_000) rebootTimes.pollFirst()
                            rebootTimes.addLast(now)
                            if (rebootTimes.size > 3) DebugLog.add("--- reboot asked " + rebootTimes.size + "x in a minute: STOPPED (loop) ---")
                            else { DebugLog.add("--- reboot (reload) ---"); player.stop(); web.loadUrl(pageUrl) }
                        }
                    }, player = player,
                        // build 8: the second window, the box's LoadURL, the loading state, a tap on no item
                        onOpenWindow = { u -> web.post { windowUrl = u } },
                        onLoadUrl = { u -> web.post { loadUrlInBox(u) } },
                        onProgress = { p -> web.post { loadPct = p } },
                        onReady = { web.post { portalReady = true } },
                        onKeyboard = { on -> web.post { showKeyboard(on) } },
                        onPortalEvent = { s -> web.post { portalEvent(s) } },
                        onTapNothing = { web.post {
                            if (player.url != null && player.rect == null && windowUrl == null) {
                                if (ctlShown) ctlShown = false
                                else {
                                    ctlShown = true; ctlTouch = System.currentTimeMillis()
                                    web.evaluateJavascript(
                                        "(function(){try{var p=stb.player,m=p.cur_media_item||{};return (p.is_tv?'1':'0')+'|'+((p.is_tv&&m.number)?(m.number+'  '):'')+(m.name||'');}catch(e){return '0|';}})()"
                                    ) { r ->
                                        val s = runCatching { JSONArray("[" + r + "]").getString(0) }.getOrDefault("0|")
                                        ctlLive = s.startsWith("1|"); ctlTitle = s.substringAfter('|')
                                    }
                                }
                            }
                        } }), "ZTBridge")
                    val js = StbBridge.injectionJs()
                    val docStart = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)
                    DebugLog.add("document-start injection supported: " + docStart)
                    if (docStart) WebViewCompat.addDocumentStartJavaScript(this, js, setOf("*"))
                    webChromeClient = object : WebChromeClient() {
                        override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                            DebugLog.add("console[" + m.messageLevel() + "] " + m.message() + "  (" + m.sourceId().substringAfterLast('/') + ":" + m.lineNumber() + ")")
                            return true
                        }
                    }
                    webViewClient = object : WebViewClient() {
                        override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                            super.onPageStarted(view, url, favicon)
                            DebugLog.add("page started: " + url)
                            portalReady = false; loadPct = 0; loadGen++      // build 8: ZapTen's loading screen again
                            if (!docStart) view.evaluateJavascript(js, null)
                        }
                        override fun onPageFinished(view: WebView, url: String?) {
                            super.onPageFinished(view, url)
                            DebugLog.add("page finished: " + url)
                            view.requestFocus()      // a TV remote's keys go to the page
                            view.evaluateJavascript(
                                "(function(){return 'gSTB=' + (typeof gSTB) + ' stb=' + (typeof stb) + ' screen=' + screen.width + 'x' + screen.height + ' inner=' + innerWidth + 'x' + innerHeight + ' bodyLen=' + (document.body ? document.body.innerHTML.length : -1);})()"
                            ) { r -> DebugLog.add("page state: " + r) }
                        }
                        override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                            super.onReceivedError(view, request, error)
                            DebugLog.add((if (request.isForMainFrame) "MAIN " else "") + "load error " + error.errorCode + " " + error.description + " : " + request.url)
                        }
                        override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, response: WebResourceResponse) {
                            super.onReceivedHttpError(view, request, response)
                            DebugLog.add((if (request.isForMainFrame) "MAIN " else "") + "HTTP " + response.statusCode + " " + response.reasonPhrase + " : " + request.url)
                        }
                        override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
                            DebugLog.add("SSL error " + error.primaryError + " : " + error.url + "  (connection refused — certificate not trusted)")
                            handler.cancel()
                        }
                    }
                    setOnKeyListener(tvKeys)      // build 8: TV-remote buttons → MAG keys
                    webRef = this
                    if (pageUrl.isNotBlank()) loadUrl(pageUrl) else DebugLog.add("no portal address saved")
                }
            }
        )

        // build 8: the box's second window — the portal's Settings page, full screen over the portal.
        // Its own stbWebWindow.close() (Exit on its first page) closes it again.
        val wurl = windowUrl
        if (wurl != null) key(wurl) {
            DisposableEffect(wurl) {
                onDispose { winRef?.let { it.stopLoading(); it.destroy() }; winRef = null; webRef?.requestFocus() }
            }
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { c ->
                    WebView(c).apply {
                        layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                        setBackgroundColor(android.graphics.Color.BLACK)
                        isVerticalScrollBarEnabled = false; isHorizontalScrollBarEnabled = false
                        overScrollMode = android.view.View.OVER_SCROLL_NEVER
                        isFocusable = true; isFocusableInTouchMode = true
                        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                        with(settings) {
                            javaScriptEnabled = true
                            domStorageEnabled = true
                            databaseEnabled = true
                            userAgentString = StbBridge.userAgent()
                            textZoom = 100      // build 12: the Settings window too (the theme's own text size)
                            @Suppress("DEPRECATION")
                            mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                            useWideViewPort = true
                            loadWithOverviewMode = false
                            setSupportZoom(false); builtInZoomControls = false; displayZoomControls = false
                            setSupportMultipleWindows(false)
                        }
                        setInitialScale((viewWidthPx / 1280f * 100f).toInt().coerceAtLeast(1))
                        val win = this
                        addJavascriptInterface(StbBridge(c.applicationContext, portal,
                            onReboot = { win.post { windowUrl = null; DebugLog.add("--- reboot (reload) ---"); player.stop(); webRef?.loadUrl(pageUrl) } },
                            player = player,
                            onCloseWindow = { win.post { windowUrl = null } },
                            onLoadUrl = { u -> win.post { loadUrlInBox(u) } },
                            onKeyboard = { on -> win.post { showKeyboard(on) } },
                            onPortalEvent = { s -> win.post { portalEvent(s) } }), "ZTBridge")
                        val js = StbBridge.injectionJs()
                        val docStart = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)
                        if (docStart) WebViewCompat.addDocumentStartJavaScript(this, js, setOf("*"))
                        webChromeClient = object : WebChromeClient() {
                            override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                                DebugLog.add("window console[" + m.messageLevel() + "] " + m.message() + "  (" + m.sourceId().substringAfterLast('/') + ":" + m.lineNumber() + ")")
                                return true
                            }
                        }
                        webViewClient = object : WebViewClient() {
                            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                                super.onPageStarted(view, url, favicon)
                                DebugLog.add("window page started: " + url)
                                if (!docStart) view.evaluateJavascript(js, null)
                            }
                            override fun onPageFinished(view: WebView, url: String?) {
                                super.onPageFinished(view, url)
                                view.requestFocus()      // the remote's keys go to the Settings page
                            }
                            override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
                                DebugLog.add("window SSL error " + error.primaryError + " : " + error.url)
                                handler.cancel()
                            }
                        }
                        setOnKeyListener(tvKeys)
                        winRef = this
                        loadUrl(wurl)
                    }
                }
            )
        }

        // build 8: ZapTen's own loading screen until the portal is up — or 15 s, so the portal's own
        // messages (a block, a login error) still show
        if (!portalReady && !loadTimedOut && windowUrl == null) ZtLoading(loadPct)

        // 3. controls (top-right): Settings · Reload — build 8: only before the portal is up (owner
        // order: Settings + Reload only before logging in; the Log and Remote buttons removed)
        if (!portalReady) Row(Modifier.align(Alignment.TopEnd).padding(10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ZtBtn("Settings") { onSettings() }
            ZtBtn("Reload") { DebugLog.add("--- reload ---"); player.stop(); webRef?.loadUrl(pageUrl) }
        }

        // build 8: StreamLine-style controls when the full-screen picture is tapped
        if (ctlShown && player.url != null && player.rect == null && windowUrl == null) ZtPlayerControls(
            title = ctlTitle, live = ctlLive, playing = ctlPlaying,
            zapEnd = if (showRemote) 280.dp else 14.dp,
            onTouch = { ctlTouch = System.currentTimeMillis() },
            onBack = { ctlShown = false; sendKey(27) },                 // Exit: leave the picture, like StreamLine's ‹ Back
            onPlayPause = { sendKey(82, alt = true) },
            onStop = { ctlShown = false; sendKey(83, alt = true) },
            onPrev = { sendKey(9, shift = true) },                    // CH−
            onNext = { sendKey(9) },                                   // CH+
            // build 10: films — StreamLine's buttons and seek bar; ◀◀ ▶▶ are the box keys (the portal's steps)
            posSec = ctlPos, lenSec = ctlLen, stripHidden = seekHoldUntil != 0L,
            onSeekTo = { s -> player.seekSec(s.coerceAtLeast(0)); ctlPos = s.coerceAtLeast(0) },
            onRew = { sendKey(66, alt = true) },
            onFf = { sendKey(70, alt = true) })

        // 4. on-screen remote for touch screens: the MAG interface only listens to remote keys
        // build 8: every MAG button; fades after 4 s; Hide › on it, and the ‹ Remote tab brings it back
        if (showRemote) ZtRemote(Modifier.align(Alignment.BottomEnd).padding(12.dp), awake = remoteAwake,
            onWake = { remoteTouch = System.currentTimeMillis() }, onHide = { showRemote = false }) { code, shift, alt ->
            when (code) {
                ZT_SETUP -> openPortalSettings()
                ZT_TV_VOL_UP -> tvVolume(android.media.AudioManager.ADJUST_RAISE)
                ZT_TV_VOL_DOWN -> tvVolume(android.media.AudioManager.ADJUST_LOWER)
                ZT_TV_MUTE -> tvVolume(android.media.AudioManager.ADJUST_TOGGLE_MUTE)
                ZT_TV_POWER -> tvOnly("TV power")
                ZT_TV_SET -> tvOnly("TV SET")
                ZT_TV_AV -> tvOnly("TV/AV")
                ZT_KB -> { sendKey(76, alt = true); toggleKeyboard() }       // the box's KB key (Alt+L) + the keyboard
                else -> sendKey(code, shift, alt)
            }
        }
        else ZtRemoteTab(Modifier.align(Alignment.BottomEnd).padding(12.dp)) { showRemote = true; remoteTouch = System.currentTimeMillis() }

        // build 19: the pointer and its hint (only drawn: a tap goes through them)
        if (ptrOn && ptrX >= 0f) {
            ZtPointer(ptrX, ptrY, ring = ptrFx != 0L)
            Text("Pointer — arrows move it · OK presses · Back = off", color = Amber, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.BottomStart).padding(14.dp)
                    .background(Color(0xF0141927), RoundedCornerShape(10.dp)).border(1.dp, Amber, RoundedCornerShape(10.dp))
                    .padding(horizontal = 12.dp, vertical = 7.dp))
        }

        if (showLog) ZtLogPanel(onClear = { DebugLog.clear() }, onCopy = {
            val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("ZapTen log", DebugLog.dump()))
        })
    }
}

@Composable
private fun ZtBtn(label: String, onClick: () -> Unit) {
    Text(label, color = TextCol, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.background(Color(0xCC141927), RoundedCornerShape(8.dp)).clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp))
}

/** A MAG remote on screen (keydown.keycodes.js): arrows, OK, Back, Exit, Menu, CH±, Info, ▶❚❚, ■, colours.
 *  Build 8: every MAG button (owner: "just add all the buttons"), same look; it fades after 4 s
 *  without a touch and wakes on the next one; "Hide ›" puts it away (the ‹ Remote tab brings it back).
 *  Build 10: the owner's MAG remote exactly (his photo): its 48 buttons in its order, the TV group
 *  outlined; the keys are the box's (lircrc of the MAG254 software: ⏻ Alt+U, SET, MUTE Alt+`, MODE
 *  Alt+G, KB, APP F12, TV F10, F1–F4, MENU F11, BACK, EXIT, INFO Alt+Y, CH± Tab/Shift+Tab, PgUp/PgDn,
 *  VOL± , ◀◀ Alt+B, ▶▶ Alt+F, ▶❚❚ Alt+R, ■ Alt+S, ASPECT F6, DEL F5). ★ Home EPG Rec removed (owner). */
@Composable
private fun ZtRemote(modifier: Modifier, awake: Boolean, onWake: () -> Unit, onHide: () -> Unit, send: (Int, Boolean, Boolean) -> Unit) {
    val fade by animateFloatAsState(if (awake) 1f else 0.3f, animationSpec = tween(600), label = "remote fade")
    @Composable
    fun K(label: String, code: Int, shift: Boolean = false, alt: Boolean = false, bg: Color = Color(0xCC1C2336), w: Int = 54,
          fg: Color = TextCol, size: Int = 14, tv: Boolean = false, power: Color? = null) {
        val keyMod = Modifier.width(w.dp).height(40.dp)
            .background(if (tv) Color(0xCC0E121C) else bg, RoundedCornerShape(9.dp))
            .let { if (tv) it.border(1.dp, Color(0xFF4A5470), RoundedCornerShape(9.dp)) else it }
            .clickable { send(code, shift, alt) }
        if (power != null) Box(keyMod, contentAlignment = Alignment.Center) { ZtPowerIcon(power) }
        else Text(label, color = fg, fontSize = (if (tv) 10 else size).sp, fontWeight = FontWeight.Bold, lineHeight = (if (tv) 11 else size + 2).sp,
            modifier = keyMod.wrapContentHeight(),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center)
    }
    Column(modifier.alpha(fade)
        .pointerInput(Unit) { awaitPointerEventScope { while (true) { awaitPointerEvent(PointerEventPass.Initial); onWake() } } }
        .background(Color(0x990B0E16), RoundedCornerShape(14.dp)).verticalScroll(rememberScrollState()).padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.width(234.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("REMOTE", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp, modifier = Modifier.weight(1f))
            Text("Hide ›", color = TextCol, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.background(Color(0xCC1C2336), RoundedCornerShape(9.dp)).clickable { onHide() }
                    .padding(horizontal = 12.dp, vertical = 6.dp))
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            K("", ZT_TV_POWER, tv = true, power = Color(0xFF5B8DFF)); K("TV\nSET", ZT_TV_SET, tv = true); K("TV/AV", ZT_TV_AV, tv = true)
            K("", 85, alt = true, power = Color(0xFFFF5A4D))
        }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { K("TV\nVOL+", ZT_TV_VOL_UP, tv = true); K("SET", ZT_SETUP, size = 13); K("MUTE", 192, alt = true, size = 12) }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { K("TV\nVOL−", ZT_TV_VOL_DOWN, tv = true); K("MODE", 71, alt = true, size = 12); K("KB", ZT_KB, size = 13) }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { K("TV\nMUTE", ZT_TV_MUTE, tv = true); K("APP", 123, size = 13); K("TV", 121, size = 13) }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            K("F1", 112, bg = Color(0xD9B03030), size = 13); K("F2", 113, bg = Color(0xD92E8B57), size = 13)
            K("F3", 114, bg = Color(0xD9C9A227), fg = Color(0xFF1A1304), size = 13); K("F4", 115, bg = Color(0xD92F5FB0), size = 13)
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { K("MENU", 122, size = 12); K("▲", 38); K("BACK", 8, size = 12) }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { K("◀", 37); K("OK", 13, bg = Color(0xCCF5B638)); K("▶", 39) }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { K("EXIT", 27, size = 12); K("▼", 40); K("INFO", 89, alt = true, size = 12) }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { K("CH+", 9, size = 13); K("PgUp", 33, size = 12); K("VOL+", 107, size = 12) }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { K("CH−", 9, shift = true, size = 13); K("PgDn", 34, size = 12); K("VOL−", 109, size = 12) }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { K("◀◀", 66, alt = true); K("▶▶", 70, alt = true); K("▶❚❚", 82, alt = true); K("■", 83, alt = true) }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { K("1", 49); K("2", 50); K("3", 51) }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { K("4", 52); K("5", 53); K("6", 54) }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { K("7", 55); K("8", 56); K("9", 57) }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { K("ASPECT", 117, size = 10); K("0", 48); K("DEL", 116, size = 12) }
    }
}

/** Build 10: the power symbol on the remote's two power keys (TV power blue, box power red). */
@Composable
private fun ZtPowerIcon(color: Color) {
    Canvas(Modifier.size(18.dp)) {
        val u = size.width / 24f
        val sw = 2.6f * u
        drawArc(color, startAngle = -56f, sweepAngle = 292f, useCenter = false,
            topLeft = Offset(4f * u, 4.4f * u), size = Size(16f * u, 16f * u), style = Stroke(width = sw, cap = StrokeCap.Round))
        drawLine(color, Offset(12f * u, 2.5f * u), Offset(12f * u, 11.5f * u), strokeWidth = sw, cap = StrokeCap.Round)
    }
}

/** Build 8: the tab that brings the hidden remote back. */
@Composable
private fun ZtRemoteTab(modifier: Modifier, onShow: () -> Unit) {
    Text("‹ Remote", color = TextCol, fontSize = 14.sp, fontWeight = FontWeight.Bold,
        modifier = modifier.background(Color(0xD9141927), RoundedCornerShape(12.dp)).clickable { onShow() }
            .padding(horizontal = 16.dp, vertical = 12.dp))
}

/** Build 8: ZapTen's own loading screen while the portal logs in and loads (its loading bar). */
@Composable
private fun ZtLoading(pct: Int) {
    Column(Modifier.fillMaxSize().background(Ink)
        .pointerInput(Unit) { awaitPointerEventScope { while (true) { awaitPointerEvent() } } },   // the page below gets no taps
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Zap", color = TextCol, fontSize = 56.sp, fontWeight = FontWeight.ExtraBold)
            Text("Ten", color = Amber, fontSize = 56.sp, fontWeight = FontWeight.ExtraBold)
        }
        Spacer(Modifier.height(22.dp))
        Text("Loading… " + pct + "%", color = Muted, fontSize = 20.sp)
        Spacer(Modifier.height(22.dp))
        Box(Modifier.width(420.dp).height(8.dp).background(Panel2, RoundedCornerShape(4.dp))) {
            Box(Modifier.fillMaxWidth(pct.coerceIn(0, 100) / 100f).fillMaxHeight().background(Amber, RoundedCornerShape(4.dp)))
        }
    }
}

/** Build 8: StreamLine's player controls over the full-screen picture (same look as Player.kt):
 *  ‹ Back · title · LIVE on top, play/pause + stop below, channel up/down on the right. */
@Composable
private fun BoxScope.ZtPlayerControls(title: String, live: Boolean, playing: Boolean, zapEnd: androidx.compose.ui.unit.Dp,
                                      onTouch: () -> Unit, onBack: () -> Unit, onPlayPause: () -> Unit, onStop: () -> Unit,
                                      onPrev: () -> Unit, onNext: () -> Unit,
                                      posSec: Long = 0, lenSec: Long = 0, stripHidden: Boolean = false,
                                      onSeekTo: (Long) -> Unit = {}, onRew: () -> Unit = {}, onFf: () -> Unit = {}) {
    Row(Modifier.align(Alignment.TopStart).fillMaxWidth().background(Color(0xCC0B0E16)).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Row(verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.background(Color(0x33FFFFFF), RoundedCornerShape(10.dp)).clickable { onBack() }
                .padding(horizontal = 12.dp, vertical = 7.dp)) {
            Text("‹", color = Amber, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(4.dp))
            Text("Back", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.width(10.dp))
        Text(title, color = TextCol, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.weight(1f))
        if (live) Row(verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.background(Color(0x33FF5449), RoundedCornerShape(8.dp)).padding(horizontal = 10.dp, vertical = 4.dp)) {
            Box(Modifier.size(8.dp).background(Color(0xFFFF5449), CircleShape))
            Spacer(Modifier.width(6.dp))
            Text("LIVE", color = Color(0xFFFF8A80), fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
    if (live) {
    Row(Modifier.align(Alignment.BottomStart).fillMaxWidth().background(Color(0xCC0B0E16)).padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically) {
        ZtCircle(if (playing) "❚❚" else "▶", 68) { onTouch(); onPlayPause() }
        ZtCircle("■", 52) { onStop() }
    }
    } else {
        // build 10: a film — StreamLine's buttons (Player.kt) and its seek bar with the times; while
        // the portal shows its own position bar (◀◀ ▶▶) the seek bar makes room for it
        Column(Modifier.align(Alignment.BottomStart).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                ZtCircle("⏮", 52) { onTouch(); onSeekTo(0) }
                ZtCircle("‹1m", 52) { onTouch(); onSeekTo((posSec - 60).coerceAtLeast(0)) }
                ZtCircle("◀◀", 52) { onTouch(); onRew() }
                ZtCircle(if (playing) "❚❚" else "▶", 68) { onTouch(); onPlayPause() }
                ZtCircle("▶▶", 52) { onTouch(); onFf() }
                ZtCircle("1m›", 52) { onTouch(); onSeekTo(if (lenSec > 0) (posSec + 60).coerceAtMost(lenSec) else posSec + 60) }
                ZtCircle("■", 52) { onStop() }
            }
            Spacer(Modifier.height(14.dp))
            if (stripHidden) Spacer(Modifier.height(140.dp))
            else Column(Modifier.fillMaxWidth().background(Color(0xCC0B0E16)).padding(horizontal = 16.dp, vertical = 12.dp)) {
                Slider(
                    value = if (lenSec > 0) (posSec.toFloat() / lenSec).coerceIn(0f, 1f) else 0f,
                    onValueChange = { f -> onTouch(); if (lenSec > 0) onSeekTo((f * lenSec).toLong()) },
                    colors = SliderDefaults.colors(thumbColor = Amber, activeTrackColor = Amber, inactiveTrackColor = Line)
                )
                Row {
                    Text(ztTime(posSec), color = TextCol, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    Spacer(Modifier.weight(1f))
                    Text("-" + ztTime(lenSec - posSec), color = Muted, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    Spacer(Modifier.width(10.dp))
                    Text(ztTime(lenSec), color = TextCol, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
    Column(Modifier.align(Alignment.CenterEnd).padding(end = zapEnd), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ZtCircle("ᐱ", 52) { onTouch(); onPrev() }
        ZtCircle("ᐯ", 52) { onTouch(); onNext() }
    }
}

/** Build 10: seconds as StreamLine shows them (Player.kt fmt): 1:02:03 / 4:05. */
private fun ztTime(sec: Long): String {
    if (sec <= 0) return "0:00"
    val h = sec / 3600; val m = (sec % 3600) / 60; val s = sec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

@Composable
private fun ZtCircle(glyph: String, size: Int, onClick: () -> Unit) {
    Box(Modifier.size(size.dp).background(Color(0xCC141927), CircleShape).border(1.dp, Line, CircleShape).clickable { onClick() },
        contentAlignment = Alignment.Center) {
        Text(glyph, color = Amber, fontSize = if (size > 60) 26.sp else 15.sp, fontWeight = FontWeight.Bold)
    }
}

/** The remote's Setup button (no MAG key code: ZapTen opens the portal's Settings tile itself). */
private const val ZT_SETUP = -1
// build 10: the remote's buttons that are not box keys (the TV group works the tablet / says it is the TV's; KB = keyboard)
private const val ZT_TV_POWER = -2
private const val ZT_TV_SET = -3
private const val ZT_TV_AV = -4
private const val ZT_TV_VOL_UP = -5
private const val ZT_TV_VOL_DOWN = -6
private const val ZT_TV_MUTE = -7
private const val ZT_KB = -8

/** A MAG key code (the portal's keydown.keycodes.js) → the Android key that makes the WebView send it. */
private fun ztAndroidKey(code: Int): Int? = when (code) {
    8 -> KeyEvent.KEYCODE_DEL
    9 -> KeyEvent.KEYCODE_TAB
    13 -> KeyEvent.KEYCODE_ENTER
    27 -> KeyEvent.KEYCODE_ESCAPE
    33 -> KeyEvent.KEYCODE_PAGE_UP
    34 -> KeyEvent.KEYCODE_PAGE_DOWN
    37 -> KeyEvent.KEYCODE_DPAD_LEFT
    38 -> KeyEvent.KEYCODE_DPAD_UP
    39 -> KeyEvent.KEYCODE_DPAD_RIGHT
    40 -> KeyEvent.KEYCODE_DPAD_DOWN
    in 48..57 -> KeyEvent.KEYCODE_0 + (code - 48)
    in 65..90 -> KeyEvent.KEYCODE_A + (code - 65)
    107 -> KeyEvent.KEYCODE_NUMPAD_ADD
    109 -> KeyEvent.KEYCODE_NUMPAD_SUBTRACT
    in 112..123 -> KeyEvent.KEYCODE_F1 + (code - 112)
    192 -> KeyEvent.KEYCODE_GRAVE
    else -> null
}

/** build 17: while the portal screen is open, MainActivity.dispatchKeyEvent gives every key here first
 *  (a TV's / Android box's remote → the MAG keys, see ZtPortalScreen). */
object ZtRemoteKeys {
    @Volatile var handler: ((KeyEvent) -> Boolean)? = null
    /** build 18: MainActivity calls it when a mouse moves or clicks (the portal screen shows its remote). */
    @Volatile var onMouse: (() -> Unit)? = null
}

/** build 17: a remote's button → the MAG key [code, shift 0/1, alt 0/1], all of them (the TV-remote buttons
 *  below, plus the D-pad, every code Android TV counts as OK, the number keys, EXIT, …); null = Android's
 *  own (Back, volume, Home, power, input, the app buttons). */
private fun ztRemoteButton(keyCode: Int): IntArray? = ztTvRemoteKey(keyCode) ?: when (keyCode) {
    KeyEvent.KEYCODE_DPAD_UP -> intArrayOf(38, 0, 0)
    KeyEvent.KEYCODE_DPAD_DOWN -> intArrayOf(40, 0, 0)
    KeyEvent.KEYCODE_DPAD_LEFT -> intArrayOf(37, 0, 0)
    KeyEvent.KEYCODE_DPAD_RIGHT -> intArrayOf(39, 0, 0)
    KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER,
    KeyEvent.KEYCODE_BUTTON_SELECT, KeyEvent.KEYCODE_BUTTON_A -> intArrayOf(13, 0, 0)   // OK
    in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> intArrayOf(48 + keyCode - KeyEvent.KEYCODE_0, 0, 0)
    in KeyEvent.KEYCODE_NUMPAD_0..KeyEvent.KEYCODE_NUMPAD_9 -> intArrayOf(48 + keyCode - KeyEvent.KEYCODE_NUMPAD_0, 0, 0)
    KeyEvent.KEYCODE_ESCAPE -> intArrayOf(27, 0, 0)                    // EXIT = Esc
    KeyEvent.KEYCODE_DEL -> intArrayOf(8, 0, 0)                        // Backspace = a MAG's BACK
    KeyEvent.KEYCODE_LAST_CHANNEL -> intArrayOf(8, 0, 0)               // last channel = BACK on TV
    KeyEvent.KEYCODE_PAGE_UP -> intArrayOf(33, 0, 0)                   // Page Up / Page Down
    KeyEvent.KEYCODE_PAGE_DOWN -> intArrayOf(34, 0, 0)
    KeyEvent.KEYCODE_MEDIA_SKIP_BACKWARD -> intArrayOf(66, 0, 1)       // ◀◀ = Alt+B
    KeyEvent.KEYCODE_MEDIA_SKIP_FORWARD -> intArrayOf(70, 0, 1)        // ▶▶ = Alt+F
    KeyEvent.KEYCODE_TV_ZOOM_MODE -> intArrayOf(117, 0, 0)             // zoom / picture size = ASPECT (F6)
    in KeyEvent.KEYCODE_F1..KeyEvent.KEYCODE_F12 -> intArrayOf(112 + keyCode - KeyEvent.KEYCODE_F1, 0, 0)
    // build 18: more remotes — menu keys, game controllers, zoom, step, close, page-like, Settings, Subtitles
    KeyEvent.KEYCODE_TV_CONTENTS_MENU, KeyEvent.KEYCODE_TV_MEDIA_CONTEXT_MENU, KeyEvent.KEYCODE_MEDIA_TOP_MENU,
    KeyEvent.KEYCODE_BUTTON_START -> intArrayOf(122, 0, 0)              // MENU = F11
    KeyEvent.KEYCODE_BUTTON_Y -> intArrayOf(89, 0, 1)                    // INFO = Alt+Y
    KeyEvent.KEYCODE_BUTTON_R1 -> intArrayOf(9, 0, 0)                    // CH+ = Tab
    KeyEvent.KEYCODE_BUTTON_L1 -> intArrayOf(9, 1, 0)                    // CH− = Shift+Tab
    KeyEvent.KEYCODE_BUTTON_R2, KeyEvent.KEYCODE_MEDIA_STEP_FORWARD -> intArrayOf(70, 0, 1)    // ▶▶ = Alt+F
    KeyEvent.KEYCODE_BUTTON_L2, KeyEvent.KEYCODE_MEDIA_STEP_BACKWARD -> intArrayOf(66, 0, 1)   // ◀◀ = Alt+B
    KeyEvent.KEYCODE_MEDIA_CLOSE -> intArrayOf(27, 0, 0)                 // EXIT
    KeyEvent.KEYCODE_ZOOM_IN, KeyEvent.KEYCODE_ZOOM_OUT -> intArrayOf(117, 0, 0)               // ASPECT = F6
    KeyEvent.KEYCODE_NAVIGATE_PREVIOUS -> intArrayOf(33, 0, 0)           // Page Up
    KeyEvent.KEYCODE_NAVIGATE_NEXT -> intArrayOf(34, 0, 0)               // Page Down
    KeyEvent.KEYCODE_SETTINGS -> intArrayOf(ZT_SETUP, 0, 0)              // SET = the portal's settings
    KeyEvent.KEYCODE_CAPTIONS -> intArrayOf(123, 0, 0)                   // Subtitles = APP (F12), full screen only
    else -> null
}

/** A TV-remote button → the MAG key [code, shift 0/1, alt 0/1]; null = leave it to Android / the page. */
private fun ztTvRemoteKey(keyCode: Int): IntArray? = when (keyCode) {
    KeyEvent.KEYCODE_CHANNEL_UP -> intArrayOf(9, 0, 0)                 // CH+  = Tab
    KeyEvent.KEYCODE_CHANNEL_DOWN -> intArrayOf(9, 1, 0)               // CH−  = Shift+Tab
    KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_MEDIA_PLAY,
    KeyEvent.KEYCODE_MEDIA_PAUSE -> intArrayOf(82, 0, 1)               // play/pause = Alt+R
    KeyEvent.KEYCODE_MEDIA_STOP -> intArrayOf(83, 0, 1)                // stop = Alt+S
    KeyEvent.KEYCODE_MEDIA_REWIND -> intArrayOf(66, 0, 1)              // ◀◀ = Alt+B
    KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> intArrayOf(70, 0, 1)        // ▶▶ = Alt+F
    KeyEvent.KEYCODE_MEDIA_NEXT -> intArrayOf(34, 0, 0)                // ▶| = Page Down
    KeyEvent.KEYCODE_MEDIA_PREVIOUS -> intArrayOf(33, 0, 0)            // |◀ = Page Up
    KeyEvent.KEYCODE_MEDIA_RECORD -> intArrayOf(87, 0, 1)              // Rec = Alt+W
    KeyEvent.KEYCODE_MEDIA_AUDIO_TRACK -> intArrayOf(71, 0, 1)         // Audio = Alt+G
    KeyEvent.KEYCODE_INFO -> intArrayOf(89, 0, 1)                      // Info = Alt+Y
    KeyEvent.KEYCODE_MENU -> intArrayOf(122, 0, 0)                     // Menu = F11
    KeyEvent.KEYCODE_GUIDE -> intArrayOf(119, 0, 0)                    // EPG = F8
    KeyEvent.KEYCODE_TV -> intArrayOf(121, 0, 0)                       // TV = F10
    KeyEvent.KEYCODE_PROG_RED -> intArrayOf(112, 0, 0)                 // colours = F1-F4
    KeyEvent.KEYCODE_PROG_GREEN -> intArrayOf(113, 0, 0)
    KeyEvent.KEYCODE_PROG_YELLOW -> intArrayOf(114, 0, 0)
    KeyEvent.KEYCODE_PROG_BLUE -> intArrayOf(115, 0, 0)
    else -> null
}

private fun android.content.Context.ztFindActivity(): android.app.Activity? {
    var c: android.content.Context? = this
    while (c is android.content.ContextWrapper) {
        if (c is android.app.Activity) return c
        c = c.baseContext
    }
    return null
}

/** build 19: the pointer — an arrow whose tip is at (x, y) in the screen's pixels, with a ring while it presses. */
@Composable
private fun ZtPointer(x: Float, y: Float, ring: Boolean) {
    val dens = LocalDensity.current.density
    Canvas(Modifier.fillMaxSize()) {
        if (ring) drawCircle(Color(0xFFF5B638), radius = 20f * dens, center = Offset(x, y), style = Stroke(width = 3f * dens))
        val s = 30f * dens / 24f
        val p = Path().apply {
            moveTo(x, y)
            lineTo(x, y + 18f * s)
            lineTo(x + 5f * s, y + 13.5f * s)
            lineTo(x + 8.5f * s, y + 20f * s)
            lineTo(x + 11.5f * s, y + 18.5f * s)
            lineTo(x + 8f * s, y + 12f * s)
            lineTo(x + 15f * s, y + 12f * s)
            close()
        }
        drawPath(p, Color.White)
        drawPath(p, Color(0xFF0B0E16), style = Stroke(width = 1.6f * dens))
    }
}

/** The log: newest at the bottom; Copy puts the whole log on the clipboard. */
@Composable
private fun ZtLogPanel(onClear: () -> Unit, onCopy: () -> Unit) {
    val lines = DebugLog.lines
    val scroll = rememberScrollState()
    LaunchedEffect(lines.size) { scroll.scrollTo(scroll.maxValue) }
    Column(Modifier.fillMaxWidth().fillMaxHeight(0.6f).padding(top = 44.dp, start = 10.dp, end = 10.dp)
        .background(Color(0xE60B0E16), RoundedCornerShape(10.dp)).padding(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("ZapTen log  ·  " + lines.size + " lines", color = Amber, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            ZtBtn("Copy") { onCopy() }
            Spacer(Modifier.width(6.dp))
            ZtBtn("Clear") { onClear() }
        }
        Spacer(Modifier.height(6.dp))
        Column(Modifier.fillMaxSize().verticalScroll(scroll)) {
            for (l in lines) Text(l, color = TextCol, fontSize = 11.sp, lineHeight = 14.sp, fontFamily = FontFamily.Monospace)
        }
    }
}
