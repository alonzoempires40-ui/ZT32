package com.zapten.app

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * The Vault — ZapTen's encryption module (ported byte-for-byte from the StreamLine project, so the
 * two apps protect the box identity the same proven way).
 *
 * WHAT IT PROTECTS AGAINST: anyone copying the app's files off the device — a rooted file manager,
 * an emulator image, a stolen/cloned box, forensic tools. Values sealed by the Vault are ciphertext
 * on disk; without THIS device's key they stay ciphertext.
 *
 * HOW: standard AES-256-GCM. The key is generated INSIDE the Android Keystore and marked
 * non-exportable. Encrypt/decrypt go into the chip; the key never comes out.
 *
 * RULES (never-crash contract):
 *  - seal() NEVER loses data: on a broken Keystore it returns the value unencrypted rather than failing.
 *  - open() accepts BOTH sealed and legacy-plaintext values.
 *  - a sealed value that can't be decrypted (foreign/lost key) reads as "" — the app re-asks to set up.
 *  - NO user-auth requirement on the key, so it works while the device is locked.
 *
 * FORMAT: "ov1:" + Base64(iv[12] + ciphertext-with-GCM-tag).
 */
object BoxVault {

    private const val KEY_ALIAS = "zapten_vault_v1"
    private const val PREFIX = "ov1:"
    private const val IV_LEN = 12
    private val lock = Any()

    fun seal(plain: String): String {
        if (plain.isEmpty() || plain.startsWith(PREFIX)) return plain
        return try {
            synchronized(lock) {
                val c = Cipher.getInstance("AES/GCM/NoPadding")
                c.init(Cipher.ENCRYPT_MODE, key())
                val ct = c.doFinal(plain.toByteArray(Charsets.UTF_8))
                val out = ByteArray(c.iv.size + ct.size)
                c.iv.copyInto(out, 0); ct.copyInto(out, c.iv.size)
                PREFIX + Base64.encodeToString(out, Base64.NO_WRAP)
            }
        } catch (_: Throwable) { plain }
    }

    fun open(stored: String?): String {
        val s = stored ?: return ""
        if (!s.startsWith(PREFIX)) return s
        return try {
            synchronized(lock) {
                val all = Base64.decode(s.substring(PREFIX.length), Base64.NO_WRAP)
                if (all.size <= IV_LEN) return ""
                val c = Cipher.getInstance("AES/GCM/NoPadding")
                c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, all, 0, IV_LEN))
                String(c.doFinal(all, IV_LEN, all.size - IV_LEN), Charsets.UTF_8)
            }
        } catch (_: Throwable) { "" }
    }

    fun isSealed(stored: String?): Boolean = stored?.startsWith(PREFIX) == true

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return kg.generateKey()
    }
}
