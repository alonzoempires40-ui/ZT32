# ZapTen — read this first

**ZapTen (`com.zapten.app`) = StreamLine build 40, copied whole, + a "portal page" mode.** Everything
below this section is StreamLine's own project brief and still applies to the 22 StreamLine files.
Owner order (ZapTen build 6): "take it all from StreamLine … and add what is here".

Portal-page mode (7 files added, nothing of StreamLine changed in behaviour):
- `PortalScreen.kt` — `ZtSetupScreen` (portal address, this box's MAC) and `ZtPortalScreen` (the
  provider's own `stalker_portal/c/` page in a transparent WebView, scaled 1280→screen width,
  on-screen remote, Settings/Reload/Log buttons, log panel). `Nav.PortalSetup` / `Nav.Portal` in
  MainActivity; ZapTen starts there. StreamLine's screens remain reachable from the setup screen.
- `StbBridge.kt` — the set-top-box API (`window.gSTB` + box globals) injected at document start:
  identity, login crypto (`GetUID`/`GetHashVersion1`), `RDir` with a SAVED environment (setenv/
  getenv), `ExecAction("reboot")` → reload, `SaveUserData`/`LoadUserData`, and the PLAYER API →
  `BoxPlayerHost`. Portal mode uses `BoxPrefs`/`BoxVault` (prefs file `zapten`, Keystore alias
  `zapten_vault_v1`) — separate from StreamLine's `Prefs`/`Vault`; the portal-mode MAC is NOT
  StreamLine's MAC.
- `BoxCrypto.kt` — MAC-derived identity: serial = upper(MD5(MAC))[0..13], device_id =
  upper(SHA-256(MAC)), device_id2 = upper(SHA-256(serial+MAC)) (MUST differ — the owner's portal
  refuses equal ids), signature = HMAC(device_id, random). Proven on the owner's portal.
- `BoxVideo.kt` — `BoxPlayerState` (the box player behind the page) using StreamLine's
  `VlcPlayer`/`MpvPlayer` unchanged + an Exo path like Player.kt; URL routing = pickEngine's;
  fallback Exo→VLC→mpv; box events 4/1/5 via `stbEvent.onEvent`.
- `DebugLog.kt` — the on-screen log (page loads, HTTP/SSL errors, console, every portal request,
  every box-API call, player steps).
- Lessons from builds 1-5 (each a thing a MAG does that the page expects): address =
  https://domain/stalker_portal/c/; device_id2 ≠ device_id; setenv must persist and reboot must
  reload (the time-server step after login); screen.height drives the 720p layout; the interface
  only listens to remote keys (touch needs the on-screen remote).
- Build 8 lessons: a MAG254 is NOT an emulator (`IsEmulator: false` — true swaps Back/Exit in the
  portal); every box answer the portal JSON-parses needs a JSON value (`[]`), or that part crashes and
  the portal stops loading every part after it; the Settings tile opens a SECOND window
  (`stbWindowMgr.openWebFavorites`, closed by `stbWebWindow.close()`); keys are sent as real Android
  key presses (`ztAndroidKey`), touch = walk the portal's own highlight with arrow keys then OK.
  Browser test bench: a fake portal + the v33 interface (assistant scratch, not shipped).
- Build 9: the gSTB catch-all makes the portal think a feature exists — answer `undefined` for
  features a MAG254 lacks (`startAplication`/`appsList` → no Applications tile). The injected
  "‹ Back" (`#zt_back`, theme `.sl_v_hint` look) shows when a `module.*.on` page is open and the
  theme's own hint is not visible; it shifts that page's `.mb_header_first` (or `#zagolovok`) right.
- Build 10: keys for the PORTAL page are sent as page key events (keyCode + shiftKey/altKey, on
  `document.body`) — as real Android keys Shift/Alt were lost; the Settings window still gets real
  keys. ◀◀/▶▶ need `stbPlayerManager.list[0].state` (2 playing, 3 paused). The APP menu's Audio /
  Subtitles come from box event 7 then 9 (`get_pids`) reading `GetAudioPIDs`/`GetSubtitlePIDs`
  (`[{"pid":…,"lang":["…",""]}]`; `GetAudioPID` must be a pid in the list). The portal calls
  `SetSubtitles` right before every `GetSubtitlePIDs` — the shim drops that one so StreamLine's
  subtitle auto-on stays. `Set3DConversionMode` → undefined (no 3D item). The players are
  StreamLine's (forced engine, "Gr Subs" title → VLC, Exo watchdog, subtitle polls, Exo subtitle
  look). Aspect = the video view's size (+ engine stretch for expand/combined). mpv:
  `video-aspect-override` "-1" = default ("no" means square pixels — do not use).
- Build 11: `RDir('vmode')` must be a mode (`720p-50`) — the TV list's preview window position comes
  from `parseInt(vmode)`; blank = no SetViewport = video full screen behind. `SetTopWin(1)` = video
  ABOVE the page: emulated by a `clip-path` hole in `document.body` at the SetViewport/SetPIG
  window (the theme's preview panel is opaque). Settings pages use `GetEnv('{"varList":[…]}')` →
  `{"result":{…},"errMsg":""}` and `SetEnv('{…}')` (JSON); values = RDir's (saved env, else defaults).
- Build 12: both portal WebViews set `textZoom = 100` — WebView otherwise follows Android's font
  size and the fixed 1280×720 TV layout overflows.
- Build 13: key delivery = `window.__ztKey(code, shift, alt)` in the shim — to `document.activeElement`,
  keydown + keypress + keyup with key/code/keyCode, digits/BACK typed into a focused text box (the adult
  PIN boxes are `ModalFormInput` text boxes). The portal's `ModalForm` buttons have no click handler
  (only the remote's OK on the focused item runs `action()`): a tap finds the owning form via
  `module.*/_items[i]._input_dom_odj === el` and runs the item. `ShowVirtualKeyboard` → Android IME.
- Build 14: Settings pages' tick boxes are a real `<input type=checkbox>` moved off screen + a `<label>`
  after it drawn as the box (`:checked + label`), no code ticks them — a MAG's browser ticks on OK,
  Chrome/WebView only on Space. The shim ticks (`click()`) on Enter keydown to a focused checkbox and on
  a tap on that label, only in the Settings window (`window.top` has `#zagolovok` + `pressKey`).
  `gSTB.SendEventToPortal(json)` (Settings pages after a save) → `B.sendEventToPortal` →
  main page `stbEvent.onPortalEvent(<JSON string>)` (the theme JSON.parses it; player.js). Never log
  its content: it can carry parent_password / settings_password.
- Build 15: Settings pages fill a tick box with `.checked = (value == "true")` (false — the portal sends
  a boolean) and then `setAttribute('checked')`. Blink sets the dirty-checkedness flag on ANY `.checked`
  write, so the attribute is ignored; the MAG's old WebKit returned early when the value was unchanged.
  The shim's `checked` setter (Settings window, checkboxes) skips a write of the current value.
- Build 16: Android WebView turns on Blink SPATIAL NAVIGATION after the first DPAD key (the on-screen
  remote's arrows are DPAD keys; so is a TV remote). In that mode Enter's keyup clicks the focused
  element itself — a checkbox toggles natively. Desktop Chromium has it off (bench: launch with
  `--enable-spatial-navigation` to match the device). The shim now notes the box on Enter keydown and,
  after keyup (`setTimeout 0`), clicks only if the state is unchanged — one tick in both modes.
- ZapTen-v16-32 (owner): a SEPARATE copy of build 16 for 32-bit boxes — identical except
  `abiFilters` = `armeabi-v7a` (one ABI, like the 64-bit build), versionName `16.0-32`, APK
  `ZapTen-v16-32.apk`. Same app id / name / signature. The 64-bit ZapTen-v16 is unchanged.
- Build 17: a REAL remote's keys never reach the WebView any more. `MainActivity.dispatchKeyEvent` asks
  `ZtRemoteKeys.handler` (set by ZtPortalScreen while it is up, portal ready or Settings window open)
  → `ztRemoteButton(keyCode)` → `sendKey` (the on-screen remote's path). Reason: the portal
  preventDefaults only Tab, so native D-pad keys also triggered the WebView's own handling (spatial
  navigation, scrolling, clicks) and unhandled keys go back to Android, which can move focus off the
  WebView. OK = DPAD_CENTER / ENTER / NUMPAD_ENTER / BUTTON_SELECT / BUTTON_A (Android TV "selection").
  BACK stays the BackHandler's; volume/Home/power/input/app keys stay Android's. Same in 64 and 32.
- Build 18: `ztRemoteButton` covers ~60 Android key codes (menus, gamepad, zoom, step, close, navigate;
  `KEYCODE_SETTINGS` → `ZT_SETUP` = openPortalSettings; `KEYCODE_CAPTIONS` → APP only when
  `player.url != null && player.rect == null`). MOUSE: the WebView gets no touch events from a mouse,
  so the shim turns a left `pointerup` (pointerType mouse, own target as for touch) into `ztTap` and
  eats the browser's following `click` — set the eat flag AFTER ztTap, or a tick box's own click()
  inside it is cancelled. Wheel → ▲/▼ via the FOCUSED frame's `__ztKey` (walk `top.document.activeElement`
  into iframes: the Settings window's first page lives in the `cont` frame). `MainActivity`
  dispatchGenericMotionEvent / dispatchTouchEvent (SOURCE_MOUSE / TOOL_TYPE_MOUSE) → `ZtRemoteKeys.onMouse`
  → first use on a non-touch device shows the on-screen remote; its tab when `hasTouch || mouseUsed`.
- Build 19: `__ztKey(8)` becomes 27 when `stb.player.on && !stb.player.is_tv` (not in a text box, not
  while `player.info.on && pos_by_numbers_input`). Settings window: a capture keydown listener turns a
  real 8 into `__ztKey(27)` (not in a text box). The theme's vclub search box is a plain `ModalForm`:
  the shim adds class `zt_search_form` to `module.vclub.search_box._dom_obj` (polled once it exists) and
  `#zt_search_css` styles it with `!important` (the theme's `.modal_form .item input:focus` would win
  otherwise). `showKeyboard(true)` also calls `InputMethodManager.showSoftInput(view, 0)`.
- Build 19: `__ztKey(8)` becomes 27 when `stb.player.on && !stb.player.is_tv` (not in a text box, not
  while `player.info.on && pos_by_numbers_input`). Settings window: a capture keydown listener turns a
  real 8 into `__ztKey(27)` (not in a text box). The theme's vclub search box is a plain `ModalForm`:
  the shim adds class `zt_search_form` to `module.vclub.search_box._dom_obj` (polled until it exists),
  `#zt_search_css` styles it with `!important` (the theme's `.modal_form .item input:focus` wins
  otherwise). `showKeyboard(true)` also calls `InputMethodManager.showSoftInput`. 32-bit only so far:
  `showRemote` starts true everywhere; the POINTER lives in the key handler — OK codes act on ACTION_UP
  (short = OK / press, ≥1 s via repeat or up-time = toggle), arrows move `ptrX/ptrY` (content-view
  pixels), Back = off; a press = ACTION_DOWN/UP MotionEvents dispatched to `android.R.id.content`;
  `ZtPointer` draws it (Canvas, no pointer input).
- Build 20: `FLAG_KEEP_SCREEN_ON` on the activity window while `player.url != null && player.isPlaying()`
  (polled every 2 s into `keepAwake`; a DisposableEffect adds / clears the flag), as Player.kt does for
  StreamLine. The portal's own screensaver already skips while `gSTB.IsPlaying()`.
- Repo: ZapTen has its OWN GitHub repo (OS-Small stays StreamLine-only). Workflow in `.github/`.

---

# CLAUDE.md — StreamLine project brief

This file is the single source of truth for the project. It serves humans and AI assistants alike
(it is both `CLAUDE.md` and the project doc). Read it fully before changing anything.
Every fact below was verified against the tree at build 17 (full audit) and kept current through build 22.
Build 37 (doc sync) brought it up to date through build 36: §1, §3, §6, §7, §8, §9, §10, §11 extended.

## 1. What this is

**StreamLine** (`com.streamline.app`) — a Ministra/Stalker-portal IPTV client for Android TV,
stripped down from **OpenStream v340** (43 → 22 Kotlin files) and renamed. Target device:
Sony KD-70XF8305 (Android 9, arm64, 2 GB RAM), driven by remote (D-pad). The owner has no local
Android toolchain: **builds happen on GitHub Actions** (repo `OS-Small`) from a source ZIP.
Debug APK ≈ 109 MB single-ABI. The app is connected to a real portal and fully working
(live TV, VOD, series, guide, catch-up, radio, weather, PiP, sleep timer).
Since builds 23-36 it is also used on a **14″ Android tablet** (touch; ≈1690 dp wide in landscape,
measured from the owner's screenshot), and it supports **two portals**, each with its own
auto-generated identity, and reports itself to the portal like a real MAG box (online + now playing).

## 2. Ground rules (the working constitution)

1. **One purpose per build.** Numbered source zips `streamline-SOURCE-v{N}-ROOT.zip`, ROOT layout
   (`settings.gradle.kts` at the zip's top level — the CI unzip step requires it).
2. **Owner compiles (CI); the assistant has no compiler.** Hand-verify everything before shipping:
   balance, symbol resolution, imports, in-zip checks. State plainly what is UNVERIFIED.
3. **Every zip gets a fresh `versionCode`** and an updated `VERSION.txt` — even doc-only builds.
   (A stale VERSION.txt inside build 242 caused real confusion once.)
4. **Delete features completely**: code + nav + settings + manifest + deps. Then run the
   deleted-symbol export scan (rule 8) — a missed export (`SmoothSession`) once broke CI.
5. **Reference-first for any layout/UI change.** The pristine v340 tree (and the 242 zip) is the
   known-good reference. Diff against it, apply ONE stated delta. No experiment chains — four
   builds were once burned nudging spacers when the correct code sat in the reference.
6. **Move aside, never delete** when juggling backups; verify the destination before removing any
   copy (a sandbox reset once destroyed the only local tree).
7. **Brutal honesty** in VERSION.txt and replies: record mistakes, caveats, and what was NOT done.
8. **Verification battery per build** (see §9): kbalance 0/0 on all files, deleted-export scan,
   NEW-vs-pristine dead-import scan, in-zip verification of the exact shipped bytes.

## 3. Toolchain facts & DO-NOT-TOUCH list

| Item | Value | Why it must not change casually |
|---|---|---|
| Gradle | **8.11.1** (pinned in CI) | Runner default (9.x) is incompatible with AGP 8.9.2. Wrapper jar is absent by design; CI supplies Gradle. |
| AGP / Kotlin / JDK | 8.9.2 / 2.1.20 / 17 | Matched set; CI sets JDK 17 explicitly. |
| SDK | compileSdk 36, targetSdk 34, minSdk 28 | |
| ABI | **arm64-v8a only** | Build 8. Halved the APK (168→109 MB). 32-bit boxes out of scope. |
| `keyAlias = "openstream"` | **NEVER rename** | The alias is baked inside the binary `app/debug.keystore`; renaming breaks signing. NOTE: there are ~8 load-bearing "openstream" strings total (keystore alias; `Vault` key alias `openstream_vault_v1`; the prefs FILE name; three on-disk log/cache filenames; the EnvCheck prefs literal) — all keyed to existing installs' data, so none can change without a migration. Plus one cosmetic: Weather's User-Agent (fixed to "StreamLine" in build 19). |
| mpv | `dev.jdtech.mpv:libmpv:0.5.1` | 1.0.0 renames the whole MPVLib API (CI-verified breakage). Do not bump without a migration build. |
| Packaging | `pickFirsts += "**/libc++_shared.so"` | VLC and mpv both bundle it; without this the merge fails. |
| R8 | `isMinifyEnabled = false` (release block) | We build **assembleDebug**, so this flag does nothing today. Enabling R8 on debug = its own risky build (mpv JNI keep-rule exists in proguard-rules.pro but is unverified under minify). |
| Coil | `io.coil-kt:coil-compose:2.7.0` | Since build 34 the detail page uses Coil's 2.x API directly (`coil.request.ImageRequest`, `coil.transform.Transformation` — object `SoftBackdrop` in VideoClub.kt). Coil 3 moves everything to `coil3.*` and changes these signatures: do not bump without a migration build. |
| Repos | OS-Small = StreamLine only | **Never put a second project's zip in OS-Small** (owner order). One project per repo. |

## 4. The three engines — DO NOT REMOVE ANY

| Engine | Handles | Why irreplaceable |
|---|---|---|
| ExoPlayer (media3 1.8.0) | HLS (`.m3u8`) | Standard adaptive streaming. |
| libVLC 3.7.0 | Greek-subtitle VOD; universal error fallback | Ships iconv; transcodes legacy Windows-1253 / ISO-8859-7 subs. **Exo cannot render this portal's embedded subs at all.** |
| libmpv 0.5.1 | MPEG-TS live | HW-decodes transport streams AND draws embedded subs where VLC's HW path can't. |

History: build 242 had only Exo+VLC and was ~100 MB smaller — libmpv **is** that 100 MB, added
deliberately for TS playback. The size is the price of the capability; the owner chose to keep it.
Router lives in `Player.kt` (`pickEngine`). Per-engine subtitle scaling (`subScaleFor`) stays in
Model — players read it — even though its settings UI was removed by owner request.

## 5. Build & CI (GitHub Actions)

Repo layout: the repo contains the **unextracted source ZIP** at its root (plus README and the
workflow). The workflow finds `settings.gradle.kts` anywhere, else unzips the newest `*.zip` into
`_src/` and builds there. Owner flow: replace the zip → Actions runs → download artifact
**StreamLine-debug-apk** (`StreamLine-v{N}.apk`) → sideload.

The proven `.github/workflows/build.yml` (recreate verbatim if ever lost — each element earned its
place through a CI failure: the setup-android action hangs on licenses and pulls a broken emulator,
hence the `yes | sdkmanager` line and no setup-android; Gradle is pinned; the locate step handles
the zip-in-repo layout):

```yaml
name: Build APK
on:
  push:
  workflow_dispatch:
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with: { distribution: temurin, java-version: "17" }
      - name: Accept Android SDK licenses (preinstalled SDK)
        run: yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --licenses > /dev/null || true
      - name: Set up Gradle 8.11.1 (matches AGP 8.9.2)
        uses: gradle/actions/setup-gradle@v4
        with: { gradle-version: "8.11.1" }
      - name: Locate or unzip the source
        id: locate
        run: |
          SETTINGS=$(find . -name settings.gradle.kts -not -path '*/build/*' -not -path './.git/*' | head -1)
          if [ -z "$SETTINGS" ]; then
            ZIP=$(ls -t *.zip 2>/dev/null | head -1)
            if [ -z "$ZIP" ]; then echo "::error::No settings.gradle.kts and no .zip in the repo."; exit 1; fi
            mkdir -p _src && unzip -q "$ZIP" -d _src
            SETTINGS=$(find _src -name settings.gradle.kts -not -path '*/build/*' | head -1)
          fi
          if [ -z "$SETTINGS" ]; then echo "::error::Zip extracted but no settings.gradle.kts inside."; exit 1; fi
          echo "dir=$(dirname "$SETTINGS")" >> "$GITHUB_OUTPUT"
      - name: Build debug APK
        working-directory: ${{ steps.locate.outputs.dir }}
        run: gradle assembleDebug --no-daemon --stacktrace
      - name: Show APK size
        run: |
          find . -name "*.apk" -path "*outputs*" -exec ls -lh {} \;
          find . -name "*.apk" -path "*outputs*" -exec stat -c '%s bytes  %n' {} \;
      - name: Upload APK artifact
        uses: actions/upload-artifact@v4
        with:
          name: StreamLine-debug-apk
          path: "**/outputs/apk/**/*.apk"
          if-no-files-found: error
```

## 6. Install & test notes

- The v7 rename made this a **new app** to Android. Coming from OpenStream:
  `adb uninstall com.openstream.app` once, then fresh-install. (Both apps can also coexist —
  useful for side-by-side comparison.)
- First launch: portal URL + the **same MAC** the provider whitelisted. Device model matters
  (MAG model picker in Connection settings).
  Since builds 23-25: the app GENERATES the MAC (and serial / device IDs / signature) itself; the
  welcome screen shows that MAC to give to the provider. The connect form has only TWO fields
  (portal address + MAC) and appears only on first run, after a disconnect, or when a connect
  fails; otherwise launch is a splash ("Connecting… Portal N") straight into the app.
  Portal 2: Settings → Connection & account → Edit portal 2 (its MAC field arrives prefilled).
- Builds 29-36 test points: series "+ My list"; player fullscreen icon (tap = controls, double tap
  = exit); category name buttons; adult Movies rails locked (PIN 0000) with no pictures; big home
  search bar opens the keyboard; portal user list shows the device ONLINE + what it plays; detail
  page = whole poster card on a blurred backdrop; 6 posters per row on tablet and TV.
- Playback test matrix after any engine/ABI/dep change: (1) a TS live channel → MPV badge;
  (2) a Greek-sub movie → VLC; (3) an HLS stream → Exo. Player top bar: 💤 sleep, PiP, CC.
- Weather: Settings → Appearance & weather → city → Save → card appears on the home menu
  (blank city hides it). Free Open-Meteo API, no key, no extra dependency.

## 7. Architecture map (22 files, verified line counts)

LOC = build-17 audit count → build 36 count (recounted at build 37). Additions since build 22 are in
brackets with their build. Total: 7794 lines at build 22, 8543 at build 36.

| File | LOC | Role |
|---|---|---|
| MainActivity.kt | 252 → 270 | Session state (null = demo), navigation host [b32 `Nav.Search(showKeyboard)`; b33 `appInForeground`, `PortalPresence` host] |
| Model.kt | 435 → 498 | `Prefs` (all persisted settings incl. sealed login via Vault), design tokens, UI models [b23-24 portal 2 + `active*` identity dispatchers; b31 PIN default 0000; b33 `activeAdId`] |
| Vault.kt | 105 | Seals portal credentials (MAC/serial/user/pass) in prefs |
| StalkerClient.kt | 1771 → 1951 | The portal API client (handshake, channels, EPG, VOD, catch-up) [b31 adult-aware search; b33 MAG presence: watchdog, play/stop logs, set_played reports] |
| ConnectAndMenu.kt | 375 → 366 | Connect/login screen + the home menu (greeting, weather, 8 tiles) [b23 splash + 2-field form; b32 big search bar] |
| BrowseScreens.kt | 631 | Live categories, channel list, VOD/series categories + poster grid [b31 `AdultLockDialog` shared; b36 grid = 6 per row] |
| VideoClub.kt | 408 → 546 | VOD home: hero banner (featured), Continue-watching / My-list / category rails [b29 series My list; b31 category buttons + locked adult rails; b34 detail page option C + `SoftBackdrop`; b36 screen-relative poster width] |
| Player.kt | 909 → 1136 | Playback screen: engine router (`pickEngine`), Exo path, keys, PiP, sleep, tracks [b30 fullscreen; b33 play reports to the portal] |
| VlcPlayer.kt | 168 | VLC engine controller |
| MpvPlayer.kt | 231 → 230 | mpv engine controller |
| Catchup.kt | 233 | Server-side catch-up archive browser (operator DVR — a KEEP feature) |
| EpgCache.kt | 194 | EPG store |
| EpgRefreshWorker.kt | 95 | Background EPG refresh (WorkManager) [b23-24 uses the ACTIVE portal; b33 adid] |
| EpgDetail.kt | 154 | Programme detail |
| MoreScreens.kt | 801 → 987 | Radio, TV Guide, Settings (5 cards), About/diagnostics [b23-28 two-portal settings; b32 Search keyboard; b33 `PortalPresence` (portal messages/commands)] |
| AccountScreens.kt | 159 → 165 | Account/subscription info |
| Weather.kt | 247 | Open-Meteo weather (`Weather` object + `WeatherCard`) — removed build 4, restored build 12 |
| ChannelCache.kt | 103 | Channel list cache |
| ConnectLog.kt | 185 → 193 | Connection diagnostics log |
| EnvCheck.kt | 74 | Environment sanity checks |
| Onboarding.kt | 66 → 100 | First-run onboarding [b25 shows the generated MAC, big demo button] |
| Polish.kt | 97 | `Modifier.tvFocus(shape, autoFocus)` (focus ring/scale/autofocus) + shared polish |

## 8. Decisions log (settled — do not relitigate silently)

- **All 3 engines stay** (owner, after the 242 comparison). PiP + sleep timer **kept**.
- **Weather** back in (build 12) — zero size cost, owner wants it.
- **Home menu layout = the 242/v340 original, verbatim** (build 16; diff-verified). The menu
  deliberately has **no auto-focus ring at open** (owner request; the original never had one).
  Other screens DO seed focus: channel list, both category lists, poster grid (4 seeds in
  BrowseScreens), hero Play button (VideoClub), portal-URL field on first-time setup only.
- **Group B dead accessors left in Model** (`addProfile, removeProfile, activeIsKids, saveMac,
  savePass, saveUser`) — dead in v340 too, near auth code, zero benefit to removing.
- **`UiMovie.portalTrailer` kept** — still populated by StalkerClient's parser; inert.
- Trailer-key accessors (`tmdbKey`) removed (build 6). Live-subs stack fully removed (build 5+7).

Settled in builds 23-36 (owner decisions):
- **Build 23 is FROZEN** — never modify the v23 zip.
- **Connect form = portal address + MAC only** (b23). Username / password / device ID 1-2 /
  signature are never shown; the app fills them automatically. Saved login → splash, no form.
- **Two portals, each with its OWN full auto-generated identity** (b24): MAC, serial, device IDs,
  signature — SecureRandom-seeded, Vault-sealed under `mac2`, `serial_2`, `dev1_2`, `dev2_2`,
  `sig_2` (made once, flag `identity2_made`). Portal 1's keys and values
  are byte-identical to before (existing logins untouched).
- **Portal buttons** (b26-28): per portal one full-width row `[ Connect to Portal N | Watching ✓ ]
  [ Edit ]`; tapping always connects (demo too); a portal with no URL opens its Edit fields.
  URL placeholder `subdomain.domain.com`.
- **Adult VOD categories are downloaded but locked** (b31) behind the app's single parental PIN,
  **default 0000** (a PIN the user saved wins; blank = lock off). While locked: no fetch, no
  pictures, hidden from Continue watching / My list / search. Same PIN guards Live TV adult groups.
- **Home search = option C** (b32): big full-width bar, keyboard opens on touch. Corner ⌕ stays.
- **Behave like a real MAG on the portal** (b33): watchdog check-ins (ONLINE), play/stop logs,
  set_played reports, portal commands/messages handled. DELIBERATELY KEPT: the second
  get_profile step, timezone cookie Europe/London, "Link: WiFi".
- **Detail page = option C** (b34): blurred backdrop strip + whole poster card (170 wide, Fit) +
  info beside it; buttons max 520 wide; same screen for movies and series.
- **Posters: 6 per row on every screen** (b36, after b34 +25% and b35 Netflix-size 260):
  rails width = (screenWidthDp − 18) ÷ 6.2 − 10; category grid `GridCells.Fixed(6)`; shape 2:3.
- **No trailers for now** (owner, b35 discussion). Portal trailer field (`trailer`/`youtube_id`)
  is read but unused; YouTube playback was removed in build 4.

## 9. Verification toolkit — and its KNOWN FALSE POSITIVES

Run before shipping any build:
1. `python3 tools/kbalance.py app/src/main/java/com/zapten/app/*.kt` → must be 0/0 everywhere.
2. **Deleted-export scan**: for every top-level symbol of every deleted file (pristine v340 is the
   symbol source), grep the surviving tree. Must be zero. (The SmoothSession lesson.)
3. **NEW-vs-pristine dead-import scan** per edited file.
4. **In-zip verification**: after packaging, read the zip and assert the exact changes are inside.

False positives to expect (documented from the build-17 audit — do not "fix" these):
- `getValue`/`setValue` imports: used implicitly by `by remember` delegation.
- `Weather.kt`: `LazyRow`/`items` imports were unused in v340 too — left as-is on restore.
- Prefs resolution by regex: `var`-declared flags (`var adultUnlocked`) and digit-suffixed names
  (`dev1`, `dev2`) evade `fun X(` / `[a-zA-Z]+` patterns.
- `tvFocus` is a **Modifier extension** (`fun Modifier.tvFocus(`) — `fun tvFocus(` finds nothing.

Added from build 29 on:
5. **Import/symbol resolver** (assistant-side Python script, not shipped in `tools/`): strips
   comments/strings, checks every used Compose/Android/Coil/coroutine symbol against explicit
   imports, star imports and project declarations, and every member call on project objects.
   **Calibrate it every build** by deleting the new imports from a copy — it must flag exactly
   those. (It catches the build-25 failure class: three missing imports in Onboarding.kt.)
6. **Differential review** against the last CI-proven build: read every changed line.
- A real compile in the assistant's sandbox is impossible: the egress policy returns 403 for
  dl.google.com, repo.maven.apache.org, services.gradle.org and pypi.org. Do not route around it;
  CI stays the compiler.
- The assistant's workspace is cleared after inactivity (it happened before the build-29 session).
  The source of truth is the latest zip in OS-Small plus the owner's downloads — rebuild from those.

## 10. Build history (condensed)

1 Cleo/voice-AI strip (Vault kept — seals login) · 2 Cast · 3 Reminders · 4 Weather+YouTube/
Trailers+Social/VPN · 5 Live subtitles (manifest → INTERNET-only) · 6 dead trailer-key accessors ·
7 **rename** OpenStream→StreamLine incl. package (fresh install; SmoothSession leak fixed after
first real CI compile) · 8 **single-ABI arm64** (168→109 MB) · 9 D-pad D1: list-screen focus
seeds · 10 menu-tile + login-field seeds · 11 hero Play focus (home) · 12 **weather restored** +
spacing · 13-15 tile-layout iterations (13 contentPadding, 14 revert, 15 centered) · 16 **menu
layout restored verbatim from the 242/v340 reference** (diff-proven; ring stays off) · 17 full
audit (zero defects) + this CLAUDE.md + tools/kbalance.py shipped in-repo ·
18 semantic fixes from the external review: ConnectLog redaction hardened (URL-encoded MAC +
device_id/signature/sn/prehash), real Active/Expired/Unknown account status + status-coloured row,
ChannelsScreen progress bar un-broken (startTs passed) · 19 remaining safe fixes: EPG harvest marks
done only on success; connect saves credentials only AFTER a successful auth; Nav.Catchup /
Nav.Episodes carry from-targets so Back returns where you came from; stale comments, Weather UA,
dead YouTube proguard keep, and this doc's "one openstream" claim corrected · 20 MAG-remote Player
D-pad: ☰ Menu toggles bar focus (amber ring, entry on the play/pause button), ℹ Info = programme
popup, CHAN± zap, 0-9 typed channel tuning, arrows/media keys unchanged · 21 D-pad complete: the
seven top-bar chips (Back / Next / sleep / home / CC / PiP / EPG) join the ring, auto-hide pauses
during bar focus, any hide path drops bar mode; engine badge deliberately touch-only · 22 this doc
sync (no code changes).

23 (**frozen**) Movies "‹ Back" chips ×3; connect splash (no details on launch); connect form cut
to portal address + MAC (user/pass + "Advanced identity" UI removed by owner order, plumbing kept);
second portal (url2/mac2, active_portal) · 24 portal 2 gets its own full auto-generated identity
(`ensureIdentity2`, `active*` dispatchers; connect + EPG worker use the active portal) · 25 welcome
screen shows the generated MAC + big "Try the demo"; Settings: yellow bar removed, honest status
line, state-aware portal buttons; switching portals clears the old channel list (first v25 zip
failed CI on 3 missing Onboarding imports → repackaged) · 26 two constant "Connect to Portal N"
buttons that always connect · 27 those buttons full-width and stacked · 28 active portal reads
"Watching ✓" again, Edit is a real button, URL placeholder `subdomain.domain.com` ·
29 series "+ My list" (+ fix: My-list state re-read per title) · 30 player fullscreen icon (bars
hidden + landscape; tap = controls, double tap = exit) · 31 category names are buttons; adult VOD
categories downloaded behind PIN 0000 with no pictures while locked · 32 big home search bar
(option C), keyboard on touch · 33 MAG-box presence on the portal: watchdog/get_events (ONLINE),
stb/log play/stop, itv/vod/archive/timeshift set_played reports, portal messages & commands
(`PortalPresence`), video_out=hdmi, adid cookie · 34 detail page option C (blurred backdrop via
Coil `SoftBackdrop` + whole poster card) + posters +25% (128→160) · 35 Netflix-size posters (260
wide, measured from Netflix on the owner's tablet) · 36 6 posters per row on every screen (TV
too): screen-relative rail width, grid `Fixed(6)` · 37 this doc sync (no code changes).
CI status as of build 37: builds 25, 28 and 29 compiled and confirmed working on the owner's
devices (26-27 are contained in 28); builds 30-36 not yet reported through CI.

## 11. Known quirks & open items

- Home menu opens with **nothing focused** (by request). First D-pad press establishes focus; on
  some devices that press is consumed silently. Restore = pass `autoFocus = index == 0` at the
  `MenuTileCard` call in ConnectAndMenu.
- Hero Play may re-grab focus if the banner leaves and re-enters composition (LaunchedEffect
  re-runs on re-entry). Acceptable on TV; noted, not fixed.
- Cosmetic couch-spacing / EPG-grid polish: only on specific on-device feedback, one delta at a
  time from the reference (rule 5).
- Optional: R8-on-debug (own build; verify mpv keep-rules), CI native-lib size-breakdown step.

Open items found in builds 23-36 (none fixed yet — each needs the owner's go):
- **BUG (pre-existing, inherited):** changing channel INSIDE the player (CHAN± / arrows / zap), the
  "Next episode" chip, and the portal's `play_channel` command change the title but keep playing
  the PREVIOUS stream. Cause: Player.kt keeps `url` in `remember { mutableStateOf(...) }` and the
  fetch `LaunchedEffect(title, retry)` returns early when `url != null`. Fix = reset the stream when
  the channel/episode changes.
- Live TV adult channels can still show (with logos) in the "All" list and in channel search —
  channels carry no adult flag of their own (b31 covered Movies/Series only).
- The Movies **hero banner** (330 tall, Crop) still cuts the portrait poster into a wide slice — the
  same problem the detail page had before b34. Owner has not decided.
- On the tablet the detail page's poster card (170 wide) is smaller than its "More like this"
  posters (≈259 after b36).
- Poster sharpness is limited by the provider's pictures (≈240 px wide): ≈2× enlargement on the
  14″ tablet (slightly soft), ≈1.2× on the TV. Shape is never distorted (2:3 kept everywhere).
- `MovieDetailScreen` in BrowseScreens.kt has no callers (unused since the 242 tree; the live
  detail page is `VideoDetailScreen` in VideoClub.kt). Left as-is.

Ideas discussed, NOT built:
- **Trailers** (owner: not for now): needs to know what the portal stores in `trailer`/`youtube_id`;
  YouTube links would need a YouTube player back in the app.
- **StreamLine look for all MAG boxes** (the portal's own `c/` client, Ministra 5.6.10, c.zip):
  (1) a new theme folder `c/template/<name>/` (CSS per screen in full/_720/_480 + `i`/`i_720`/
  `i_480` images + fonts; chosen by the portal via `loader.set_template`) — colours/fonts only,
  classic layout; (2) editing the shared layout JS (`vclub.js`, `layer.list.js`, …) — risky, all
  boxes, overwritten by portal updates; (3) a separate web app via the built-in launcher redirect
  (`xpcom.common.js` ≈ line 861: theme name containing `smart_launcher` + `launcher_url` → the box
  opens that URL instead of `c/`). Suggested: (1) first, then (3). The server side is not in c.zip.

## 12. Build-17 audit record

Checks run on the full tree: balance 22/22 OK · deleted-export scan clean · all focus seeds match
design (4+1+1, menu 0) · weather wired end-to-end (4 prefs, all called) · manifest = INTERNET-only,
PiP flag present, no stray receivers/services · theme/label/app_name lockstep · gradle: single-ABI,
3 engines, pickFirst, keyAlias intact · every cross-file composable defined exactly once · zero new
dead imports vs pristine. **Result: zero code defects; three audit-regex artifacts documented in §9.**
